import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Volume2, VolumeX, Sparkles, Menu, X, Calendar, FileText, Clapperboard } from 'lucide-react';
import { soundFx } from '../utils/audioFx';
import { LanguageSwitcher } from './LanguageSwitcher';

interface Props {
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
  grainEnabled: boolean;
  setGrainEnabled: (val: boolean) => void;
  onOpenBooking: () => void;
  onOpenCV: () => void;
}

const NAV_LINKS = [
  { key: 'about', href: '#about' },
  { key: 'skills', href: '#skills' },
  { key: 'experience', href: '#experience' },
  { key: 'projects', href: '#projects' },
  { key: 'education', href: '#education' },
  { key: 'contact', href: '#contact' },
];

export const Navbar: React.FC<Props> = ({
  soundEnabled,
  setSoundEnabled,
  grainEnabled,
  setGrainEnabled,
  onOpenBooking,
  onOpenCV,
}) => {
  const { t } = useTranslation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSoundToggle = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundFx.setEnabled(next);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'py-3 bg-black/90 backdrop-blur-xl border-b border-[#00FF66]/20 shadow-[0_10px_30px_rgba(0,0,0,0.8)]'
          : 'py-5 bg-gradient-to-b from-black/80 to-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Logo */}
        <a
          href="#"
          onClick={() => soundFx.playClick()}
          className="flex items-center gap-3 group"
        >
          <div className="w-11 h-11 rounded-xl bg-black border border-[#00FF66] flex items-center justify-center shadow-[0_0_12px_rgba(0,255,102,0.3)] group-hover:shadow-[0_0_20px_rgba(0,255,102,0.8)] transition-all duration-300">
            <span className="font-heading font-extrabold text-[#00FF66] text-lg tracking-tighter">MB</span>
          </div>
          <div className="hidden sm:block">
            <span className="font-heading font-extrabold text-white text-sm md:text-base tracking-widest block uppercase group-hover:text-[#00FF66] transition-colors">
              {t('footer.title')}
            </span>
            <span className="text-[10px] text-[#A0A0A0] tracking-[0.25em] uppercase block font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00FF66] animate-pulse" />
              RABAT • CREATIVE DIR
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center space-x-7">
          {NAV_LINKS.map((link) => (
            <a
              key={link.key}
              href={link.href}
              onMouseEnter={() => soundFx.playHover()}
              onClick={() => soundFx.playClick()}
              className="text-sm font-medium text-[#A0A0A0] hover:text-[#00FF66] tracking-wide transition-colors relative py-1 group"
            >
              {t(`nav.${link.key}`)}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#00FF66] group-hover:w-full transition-all duration-300 shadow-[0_0_8px_#00FF66]" />
            </a>
          ))}
        </nav>

        {/* Controls */}
        <div className="hidden md:flex items-center space-x-2.5">
          <LanguageSwitcher />

          <button
            onClick={handleSoundToggle}
            title={soundEnabled ? t('nav.soundOff') : t('nav.soundOn')}
            className={`p-2 rounded-full border transition-all duration-300 ${
              soundEnabled
                ? 'border-[#00FF66] text-[#00FF66] bg-[#0D5C2A]/30 box-glow'
                : 'border-white/10 text-[#A0A0A0] hover:border-white/30 hover:text-white'
            }`}
          >
            {soundEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
          </button>

          <button
            onClick={() => {
              setGrainEnabled(!grainEnabled);
              soundFx.playClick();
            }}
            title={grainEnabled ? t('nav.grainOff') : t('nav.grainOn')}
            className={`p-2 rounded-full border transition-all duration-300 ${
              grainEnabled
                ? 'border-[#00FF66] text-[#00FF66] bg-[#0D5C2A]/30 box-glow'
                : 'border-white/10 text-[#A0A0A0] hover:border-white/30 hover:text-white'
            }`}
          >
            <Sparkles size={15} />
          </button>

          <button
            onClick={() => {
              soundFx.playClick();
              onOpenCV();
            }}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg btn-outline-neon flex items-center gap-1.5"
          >
            <FileText size={13} />
            <span>{t('nav.cvSpecs')}</span>
          </button>

          <button
            onClick={() => {
              soundFx.playClick();
              onOpenBooking();
            }}
            className="px-4 py-2 text-xs font-semibold rounded-lg btn-neon flex items-center gap-1.5 tracking-wider uppercase"
          >
            <Calendar size={13} />
            <span>{t('nav.bookProduction')}</span>
          </button>
        </div>

        {/* Mobile */}
        <div className="flex items-center gap-2 md:hidden">
          <button
            onClick={() => {
              soundFx.playClick();
              onOpenBooking();
            }}
            className="px-3 py-1.5 text-xs font-semibold rounded-md btn-neon uppercase tracking-wider"
          >
            {t('nav.bookProduction')}
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(!mobileMenuOpen);
              soundFx.playClick();
            }}
            className="p-2 rounded-lg border border-[#00FF66]/30 text-white hover:text-[#00FF66]"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-black/95 border-b border-[#00FF66]/30 px-6 py-6 backdrop-blur-xl">
          <div className="flex flex-col space-y-4">
            {NAV_LINKS.map((link) => (
              <a
                key={link.key}
                href={link.href}
                onClick={() => {
                  soundFx.playClick();
                  setMobileMenuOpen(false);
                }}
                className="text-base font-semibold text-white hover:text-[#00FF66] py-2 border-b border-white/10 flex items-center justify-between"
              >
                <span>{t(`nav.${link.key}`)}</span>
                <span className="text-[#00FF66] text-xs font-mono">→</span>
              </a>
            ))}
            <div className="pt-4 flex items-center justify-between gap-3 border-t border-white/10">
              <LanguageSwitcher />
              <button
                onClick={() => {
                  soundFx.playClick();
                  setMobileMenuOpen(false);
                  onOpenCV();
                }}
                className="flex-1 py-2 rounded-lg btn-outline-neon text-xs font-semibold flex items-center justify-center gap-2"
              >
                <Clapperboard size={14} />
                {t('nav.cvSpecs')}
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
