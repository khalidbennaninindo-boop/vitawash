import React from 'react';
import { useTranslation } from 'react-i18next';
import { ArrowUp } from 'lucide-react';
import { soundFx } from '../utils/audioFx';

export const Footer: React.FC = () => {
  const { t } = useTranslation();

  const scrollToTop = () => {
    soundFx.playClick();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-black border-t border-[#00FF66]/30 overflow-hidden py-14">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-gradient-to-t from-[#00FF66]/15 via-[#0D5C2A]/5 to-transparent blur-xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-black border border-[#00FF66] flex items-center justify-center text-[#00FF66] font-heading font-extrabold text-lg shadow-[0_0_15px_rgba(0,255,102,0.4)]">
            MB
          </div>
          <div>
            <span className="font-heading font-extrabold text-white uppercase text-base tracking-widest block">{t('footer.title')}</span>
            <span className="text-[11px] font-mono text-[#00FF66] uppercase tracking-[0.2em] block">{t('footer.subtitle')}</span>
          </div>
        </div>

        <div className="text-sm font-medium text-[#A0A0A0] tracking-wider">{t('footer.copyright')}</div>

        <button
          onClick={scrollToTop}
          onMouseEnter={() => soundFx.playHover()}
          className="p-3 rounded-xl bg-white/5 hover:bg-[#00FF66] text-white hover:text-black border border-white/10 hover:border-[#00FF66] transition-all duration-300 shadow-[0_0_15px_rgba(0,255,102,0.1)] hover:shadow-[0_0_25px_rgba(0,255,102,0.8)] flex items-center gap-2 group text-xs font-mono font-bold uppercase"
        >
          <span>{t('footer.top')}</span>
          <ArrowUp size={16} className="group-hover:-translate-y-1 transition-transform" />
        </button>
      </div>
    </footer>
  );
};
