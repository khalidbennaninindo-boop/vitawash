import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ADDITIONAL_PROJECTS, AdditionalProject } from '../data/additionalProjectsData';
import { Play, X, Film, ExternalLink, Loader } from 'lucide-react';
import { soundFx } from '../utils/audioFx';
import { SectionHeading } from './SectionHeading';

export const AdditionalProjects: React.FC = () => {
  const { t } = useTranslation();
  const [activeLightbox, setActiveLightbox] = useState<AdditionalProject | null>(null);
  const [iframeLoading, setIframeLoading] = useState(false);

  const openLightbox = (project: AdditionalProject) => {
    soundFx.playClick();
    setIframeLoading(true);
    setActiveLightbox(project);
  };

  return (
    <section id="more-projects" className="relative py-28 bg-black border-t border-white/5 overflow-hidden">
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-[#0D5C2A]/10 rounded-full blur-[180px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionHeading
          badge={t('additionalProjects.badge')}
          title={t('additionalProjects.title')}
          accent={t('additionalProjects.titleAccent')}
          description={t('additionalProjects.description')}
          align="center"
        />

        {/* Video Gallery */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {ADDITIONAL_PROJECTS.map((project) => (
            <div
              key={project.id}
              onClick={() => openLightbox(project)}
              className="group cursor-pointer rounded-2xl overflow-hidden glass-panel border border-white/10 hover:border-[#00FF66] transition-all duration-500 hover:shadow-[0_15px_35px_-10px_rgba(0,255,102,0.25)]"
            >
              {/* Video thumbnail */}
              <div className="relative aspect-video overflow-hidden bg-black/90">
                <img
                  src={project.thumbnailUrl}
                  alt={project.title}
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                  className="w-full h-full object-cover filter contrast-110 saturate-[0.85] group-hover:scale-110 group-hover:saturate-100 transition-all duration-700"
                />
                {/* Fallback gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#0D5C2A]/40 via-black to-black/90" />

                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent opacity-80 group-hover:opacity-50 transition-opacity duration-300" />

                {/* Category badge */}
                <div className="absolute top-3 left-3 z-10">
                  <span className="px-2.5 py-1 rounded-full bg-black/75 border border-[#00FF66]/50 text-[#00FF66] text-[10px] font-mono font-semibold uppercase tracking-wider backdrop-blur-md">
                    {project.category}
                  </span>
                </div>

                {/* Play button */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 scale-75 group-hover:scale-100">
                  <div className="w-14 h-14 rounded-full bg-[#00FF66] text-black flex items-center justify-center shadow-[0_0_25px_#00FF66]">
                    <Play size={24} className="fill-black ml-1" />
                  </div>
                </div>

                {/* Video indicator */}
                <div className="absolute bottom-3 right-3 flex items-center gap-1 text-[10px] font-mono text-white/70 bg-black/60 px-2 py-1 rounded">
                  <Film size={10} className="text-[#00FF66]" />
                  VIDEO
                </div>
              </div>

              {/* Content */}
              <div className="p-5 bg-black/80">
                <span className="text-xs font-mono text-[#00FF66] uppercase tracking-wider block mb-1">
                  {project.clientOrArtist} • {project.year}
                </span>
                <h3 className="text-base font-heading font-extrabold text-white group-hover:text-[#00FF66] transition-colors uppercase line-clamp-1">
                  {project.title}
                </h3>
                <p className="text-xs text-[#A0A0A0] mt-2 line-clamp-2 leading-relaxed">{project.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-3 p-6 rounded-2xl glass-card border border-[#00FF66]/40 shadow-2xl">
            <Film className="text-[#00FF66]" size={28} />
            <div className="text-left">
              <h4 className="text-sm font-heading font-extrabold text-white uppercase">{t('additionalProjects.ctaTitle')}</h4>
              <p className="text-xs text-[#A0A0A0] mt-0.5">{t('additionalProjects.ctaDescription')}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox Video Player - Using Google Drive iframe preview */}
      {activeLightbox && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 md:p-10 animate-in fade-in duration-300">
          <div className="absolute top-6 right-6 z-10 flex items-center gap-4">
            <span className="text-xs font-mono text-[#00FF66] bg-black border border-[#00FF66]/40 px-3 py-1 rounded-full uppercase">
              VIDEO PLAYER • GOOGLE DRIVE
            </span>
            <button
              onClick={() => {
                soundFx.playClick();
                setActiveLightbox(null);
              }}
              className="p-3 rounded-full bg-white/10 hover:bg-[#00FF66] text-white hover:text-black transition-all"
            >
              <X size={24} />
            </button>
          </div>

          <div className="max-w-5xl w-full max-h-[90vh] overflow-y-auto bg-[#080d0a] border border-[#00FF66]/40 rounded-2xl shadow-[0_0_50px_rgba(0,255,102,0.2)] overflow-hidden">
            {/* Google Drive iframe embed */}
            <div className="relative aspect-video w-full bg-black">
              {iframeLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black">
                  <Loader className="text-[#00FF66] animate-spin" size={40} />
                  <span className="text-xs font-mono text-[#A0A0A0] uppercase tracking-widest">LOADING VIDEO...</span>
                </div>
              )}
              <iframe
                key={activeLightbox.previewUrl}
                src={activeLightbox.previewUrl}
                className="w-full h-full"
                style={{ border: 0 }}
                allow="autoplay; encrypted-media"
                allowFullScreen
                onLoad={() => setIframeLoading(false)}
              />
            </div>

            {/* Details */}
            <div className="p-8">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-white/10">
                <div>
                  <span className="text-xs font-mono text-[#00FF66] uppercase tracking-widest block mb-1">
                    {activeLightbox.clientOrArtist} • {activeLightbox.category}
                  </span>
                  <h2 className="text-2xl sm:text-4xl font-heading font-extrabold uppercase text-white">
                    {activeLightbox.title}
                  </h2>
                </div>
                <div className="text-sm font-mono text-[#00FF66] bg-[#0D5C2A]/30 px-4 py-2 rounded-xl border border-[#00FF66]/40">
                  YEAR: {activeLightbox.year}
                </div>
              </div>

              <div className="py-6 space-y-4">
                <h4 className="text-xs font-mono uppercase text-[#A0A0A0] tracking-widest">PROJECT OVERVIEW</h4>
                <p className="text-base sm:text-lg text-white/90 leading-relaxed">{activeLightbox.description}</p>

                <div className="pt-4 flex flex-wrap gap-2">
                  {activeLightbox.tags.map((tag, i) => (
                    <span key={i} className="text-xs font-semibold px-3 py-1 rounded-lg bg-[#0D5C2A]/50 text-[#00FF66] border border-[#00FF66]/30">
                      ★ {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-6 border-t border-white/10 flex items-center justify-between flex-wrap gap-3">
                <span className="text-xs text-[#A0A0A0]/60 font-mono">
                  DIRECTED BY MOHAMMED BELHOUARI • RABAT, MOROCCO
                </span>
                <a
                  href={activeLightbox.previewUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2.5 rounded-lg btn-outline-neon text-xs font-bold uppercase tracking-wider flex items-center gap-2"
                >
                  <ExternalLink size={14} />
                  Open in Google Drive
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
