import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { X, Calendar as CalendarIcon, Clock, CheckCircle2, Film, Camera, Layers, Video } from 'lucide-react';
import { soundFx } from '../utils/audioFx';
import confetti from 'canvas-confetti';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const SERVICE_KEYS = ['musicVideo', 'commercial', 'photography', 'festival'];
const SERVICE_ICONS = [Film, Video, Camera, Layers];

export const BookingModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState('musicVideo');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('morning');
  const [clientName, setClientName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('Rabat, Morocco (On-site)');
  const [booked, setBooked] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    soundFx.playSuccess();
    setBooked(true);
    confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 }, colors: ['#00FF66', '#0D5C2A', '#FFFFFF'] });
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative max-w-2xl w-full bg-[#0a0f0c] border border-[#00FF66]/50 rounded-3xl shadow-[0_0_50px_rgba(0,255,102,0.3)] p-6 sm:p-10 text-white overflow-hidden max-h-[95vh] overflow-y-auto">
        <button onClick={() => { soundFx.playClick(); onClose(); }} className="absolute top-6 right-6 p-2 rounded-xl bg-white/10 hover:bg-[#00FF66] text-white hover:text-black transition-colors">
          <X size={20} />
        </button>

        {booked ? (
          <div className="text-center py-10 space-y-6">
            <div className="w-20 h-20 rounded-full bg-[#00FF66]/20 border-2 border-[#00FF66] text-[#00FF66] mx-auto flex items-center justify-center shadow-[0_0_30px_#00FF66]">
              <CheckCircle2 size={42} />
            </div>
            <h3 className="text-3xl font-heading font-extrabold uppercase text-glow">{t('booking.scheduled')}</h3>
            <p
              className="text-sm text-[#A0A0A0] max-w-md mx-auto leading-relaxed"
              dangerouslySetInnerHTML={{
                __html: t('booking.lockedDown', {
                  date: date || t('booking.requestedDate'),
                  time: t(`booking.form.timeOptions.${time}`),
                  service: t(`booking.services.${selectedService}.name`),
                }),
              }}
            />
            <div className="p-4 rounded-xl bg-black/60 border border-white/10 text-xs font-mono text-left space-y-1 text-[#A0A0A0]">
              <div><strong className="text-white">{t('booking.client')}</strong> {clientName || t('booking.valuedPartner')}</div>
              <div><strong className="text-white">{t('booking.phoneWhatsapp')}</strong> {phone || t('booking.providedFile')}</div>
              <div><strong className="text-white">{t('booking.location')}</strong> {location}</div>
            </div>
            <p className="text-xs text-[#00FF66] font-mono">{t('booking.reviewMessage')}</p>
            <button
              onClick={() => {
                soundFx.playClick();
                setBooked(false);
                setStep(1);
                onClose();
              }}
              className="px-8 py-3 rounded-xl btn-neon text-xs font-bold uppercase tracking-wider mt-4"
            >
              {t('booking.return')}
            </button>
          </div>
        ) : (
          <div>
            <div className="mb-6">
              <span className="text-xs font-mono text-[#00FF66] uppercase tracking-[0.2em] block mb-1">{t('booking.productionStudio')}</span>
              <h3 className="text-2xl sm:text-4xl font-heading font-extrabold uppercase">
                {t('booking.title')} <span className="text-[#00FF66]">{t('booking.titleAccent')}</span>
              </h3>
              <p className="text-xs text-[#A0A0A0] mt-1">
                {t('booking.step', { current: step })} {step === 1 ? t('booking.step1') : t('booking.step2')}
              </p>
            </div>

            {step === 1 ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {SERVICE_KEYS.map((key) => {
                    const Icon = SERVICE_ICONS[SERVICE_KEYS.indexOf(key)];
                    const isSelected = selectedService === key;
                    return (
                      <div
                        key={key}
                        onClick={() => {
                          soundFx.playClick();
                          setSelectedService(key);
                        }}
                        className={`p-5 rounded-2xl cursor-pointer transition-all border flex flex-col justify-between ${
                          isSelected
                            ? 'bg-[#0D5C2A]/50 border-[#00FF66] shadow-[0_0_20px_rgba(0,255,102,0.3)]'
                            : 'bg-black/60 border-white/10 hover:border-[#00FF66]/50'
                        }`}
                      >
                        <div className="p-3 rounded-xl bg-black border border-white/10 w-fit text-[#00FF66] mb-4">
                          <Icon size={22} />
                        </div>
                        <div>
                          <h4 className="text-base font-heading font-bold text-white uppercase">{t(`booking.services.${key}.name`)}</h4>
                          <p className="text-xs text-[#A0A0A0] mt-1">{t(`booking.services.${key}.desc`)}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="pt-6 flex justify-end">
                  <button onClick={() => { soundFx.playClick(); setStep(2); }} className="px-8 py-3.5 rounded-xl btn-neon text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                    <span>{t('booking.proceed')}</span>
                    <span>→</span>
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleConfirm} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2 flex items-center gap-1.5">
                      <CalendarIcon size={14} /> {t('booking.form.date')}
                    </label>
                    <input type="date" required value={date} onChange={(e) => setDate(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-black border border-white/20 text-white text-sm focus:border-[#00FF66] focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2 flex items-center gap-1.5">
                      <Clock size={14} /> {t('booking.form.time')}
                    </label>
                    <select value={time} onChange={(e) => setTime(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-black border border-white/20 text-white text-sm focus:border-[#00FF66] focus:outline-none">
                      {['morning', 'afternoon', 'evening', 'flexible'].map((key) => (
                        <option key={key} value={key}>{t(`booking.form.timeOptions.${key}`)}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2">{t('booking.form.name')}</label>
                    <input type="text" required placeholder={t('booking.form.placeholders.name')} value={clientName} onChange={(e) => setClientName(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-black border border-white/20 text-white text-sm focus:border-[#00FF66] focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2">{t('booking.form.phone')}</label>
                    <input type="tel" required placeholder={t('booking.form.placeholders.phone')} value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-black border border-white/20 text-white text-sm focus:border-[#00FF66] focus:outline-none" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2">{t('booking.form.logistics')}</label>
                  <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-black border border-white/20 text-white text-sm focus:border-[#00FF66] focus:outline-none" />
                </div>

                <div className="pt-4 flex justify-between items-center border-t border-white/10">
                  <button type="button" onClick={() => { soundFx.playClick(); setStep(1); }} className="text-xs font-mono text-[#A0A0A0] hover:text-white underline">
                    {t('booking.form.back')}
                  </button>
                  <button type="submit" className="px-8 py-3.5 rounded-xl btn-neon text-xs font-extrabold uppercase tracking-widest shadow-xl">
                    {t('booking.form.confirm')}
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
