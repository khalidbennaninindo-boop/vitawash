import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { PROJECTS_DATA, FEATURED_ARTISTS } from '../data/portfolioData';
import { Project, ProjectCategory } from '../types/portfolio';
import { Play, Maximize2, X, Filter, Sparkles, Tag, Film, Video, ExternalLink } from 'lucide-react';
import { soundFx } from '../utils/audioFx';
import { SectionHeading } from './SectionHeading';

interface Props {
  onOpenBooking: () => void;
}

const RAW_CATEGORIES: ('All' | ProjectCategory)[] = [
  'All',
  'Music Videos',
  'Commercials',
  'Photography',
  'Festivals',
  'Fashion',
  'Behind The Scenes',
  'Motion Graphics',
];

const CATEGORY_I18N_KEY: Record<string, string> = {
  'Music Videos': 'musicVideos',
  'Commercials': 'commercials',
  'Photography': 'photography',
  'Festivals': 'festivals',
  'Fashion': 'fashion',
  'Behind The Scenes': 'behindScenes',
  'Motion Graphics': 'motionGraphics',
};

export const FeaturedProjects: React.FC<Props> = ({ onOpenBooking }) => {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState<'All' | ProjectCategory>('All');
  const [activeLightbox, setActiveLightbox] = useState<Project | null>(null);
  const [selectedArtist, setSelectedArtist] = useState<string | null>(null);

  const filteredProjects = PROJECTS_DATA.filter((proj) => {
    const matchesCategory = selectedCategory === 'All' || proj.category === selectedCategory;
    const matchesArtist =
      !selectedArtist ||
      proj.clientOrArtist.toLowerCase().includes(selectedArtist.toLowerCase()) ||
      proj.title.toLowerCase().includes(selectedArtist.toLowerCase()) ||
      proj.description.toLowerCase().includes(selectedArtist.toLowerCase());
    return matchesCategory && matchesArtist;
  });

  return (
    <section id="projects" className="relative py-28 bg-black border-t border-white/5 overflow-hidden">
      <div className="absolute top-1/3 left-0 w-[600px] h-[600px] bg-[#00FF66]/5 rounded-full blur-[200px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          badge={t('projects.badge')}
          title={t('projects.title')}
          accent={t('projects.titleAccent')}
          description={t('projects.description')}
        />

        {/* Artists */}
        <div className="mb-14 p-6 rounded-2xl glass-panel border border-white/10">
          <div className="flex items-center justify-between gap-2 mb-4">
            <h3 className="text-xs font-mono uppercase text-[#00FF66] tracking-[0.2em] flex items-center gap-2">
              <Sparkles size={14} />
              <span>{t('projects.featuredCollaborations')}</span>
            </h3>
            {selectedArtist && (
              <button
                onClick={() => {
                  soundFx.playClick();
                  setSelectedArtist(null);
                }}
                className="text-xs font-mono text-white underline hover:text-[#00FF66]"
              >
                {t('projects.clearFilter')}
              </button>
            )}
          </div>

          <div className="flex flex-wrap gap-2">
            {FEATURED_ARTISTS.map((artist, idx) => {
              const isSelected = selectedArtist === artist;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    soundFx.playClick();
                    setSelectedArtist(isSelected ? null : artist);
                  }}
                  onMouseEnter={() => soundFx.playHover()}
                  className={`text-xs px-3.5 py-1.5 rounded-full font-medium transition-all duration-300 border ${
                    isSelected
                      ? 'bg-[#00FF66] text-black border-[#00FF66] font-bold shadow-[0_0_15px_rgba(0,255,102,0.8)]'
                      : 'bg-black/80 text-white/85 hover:text-[#00FF66] border-white/10 hover:border-[#00FF66]/50'
                  }`}
                >
                  ★ {artist}
                </button>
              );
            })}
          </div>
        </div>

        {/* Category filter */}
        <div className="flex flex-wrap items-center gap-2 md:gap-3 mb-12 pb-4 border-b border-white/10 overflow-x-auto">
          <span className="text-xs font-mono text-[#A0A0A0] mr-2 flex items-center gap-1">
            <Filter size={14} className="text-[#00FF66]" /> {t('projects.filterBy')}
          </span>
          {RAW_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                soundFx.playClick();
                setSelectedCategory(cat);
              }}
              onMouseEnter={() => soundFx.playHover()}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold tracking-wide uppercase transition-all duration-300 whitespace-nowrap ${
                selectedCategory === cat
                  ? 'btn-neon shadow-[0_0_15px_rgba(0,255,102,0.5)]'
                  : 'bg-black/60 text-[#A0A0A0] border border-white/10 hover:border-[#00FF66]/40 hover:text-white'
              }`}
            >
              {cat === 'All' ? t('projects.all') : t(`projects.categories.${CATEGORY_I18N_KEY[cat] || cat}`)}
            </button>
          ))}
        </div>

        {/* Grid */}
        {filteredProjects.length === 0 ? (
          <div className="py-20 text-center glass-panel rounded-2xl border border-white/10">
            <Film size={44} className="text-[#00FF66] mx-auto mb-4 opacity-70 animate-bounce" />
            <h3 className="text-xl font-heading font-bold text-white uppercase">{t('projects.noMatch')}</h3>
            <p className="text-sm text-[#A0A0A0] max-w-md mx-auto mt-2">{t('projects.noMatchDesc')}</p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSelectedArtist(null);
              }}
              className="mt-6 px-6 py-2.5 rounded-xl btn-neon text-xs uppercase"
            >
              {t('projects.resetFilters')}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, idx) => (
              <div
                key={project.id}
                onClick={() => {
                  soundFx.playClick();
                  setActiveLightbox(project);
                }}
                onMouseEnter={() => soundFx.playHover()}
                className={`group cursor-pointer rounded-2xl overflow-hidden glass-panel border border-white/10 hover:border-[#00FF66] transition-all duration-500 flex flex-col justify-between hover:shadow-[0_15px_35px_-10px_rgba(0,255,102,0.25)] ${
                  project.featured && idx % 3 === 0 ? 'md:col-span-2 lg:col-span-2' : ''
                }`}
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-black/90">
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover filter contrast-110 saturate-[0.85] group-hover:scale-105 group-hover:saturate-100 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-80 group-hover:opacity-60 transition-opacity duration-300" />

                  <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10">
                    <span className="px-3 py-1 rounded-full bg-black/75 border border-[#00FF66]/50 text-[#00FF66] text-xs font-mono font-semibold uppercase tracking-wider backdrop-blur-md">
                      {t(`projects.categories.${CATEGORY_I18N_KEY[project.category] || 'all'}`, project.category)}
                    </span>
                    <span className="text-xs font-mono text-white/80 bg-black/60 px-2.5 py-1 rounded border border-white/10">
                      {project.year}
                    </span>
                  </div>

                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 scale-75 group-hover:scale-100">
                    <div className="w-14 h-14 rounded-full bg-[#00FF66] text-black flex items-center justify-center shadow-[0_0_25px_#00FF66]">
                      {project.youtubeId || project.videoUrl ? <Play size={24} className="fill-black ml-1" /> : <Maximize2 size={22} />}
                    </div>
                  </div>
                </div>

                <div className="p-6 flex-1 flex flex-col justify-between bg-black/80">
                  <div>
                    <span className="text-xs font-mono text-[#00FF66] uppercase tracking-wider block mb-1">
                      {project.clientOrArtist}
                    </span>
                    <h3 className="text-xl font-heading font-extrabold text-white group-hover:text-[#00FF66] transition-colors uppercase line-clamp-2">
                      {project.title}
                    </h3>
                    <p className="text-xs text-[#A0A0A0] mt-2 line-clamp-2 leading-relaxed">{project.description}</p>
                  </div>
                  <div className="mt-5 pt-4 border-t border-white/10 flex flex-wrap items-center gap-1.5">
                    {project.tags.map((tag, tIdx) => (
                      <span key={tIdx} className="text-[10px] font-mono uppercase bg-[#0D5C2A]/30 text-white/90 px-2 py-0.5 rounded border border-[#00FF66]/20 flex items-center gap-1">
                        <Tag size={10} className="text-[#00FF66]" />
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* CTA */}
        <div className="mt-16 p-8 rounded-2xl glass-card border border-[#00FF66]/40 text-center flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="text-left">
            <h4 className="text-xl font-heading font-extrabold text-white uppercase">{t('projects.cta.title')}</h4>
            <p className="text-xs sm:text-sm text-[#A0A0A0] mt-1">{t('projects.cta.description')}</p>
          </div>
          <button
            onClick={() => {
              soundFx.playClick();
              onOpenBooking();
            }}
            className="px-6 py-3 rounded-xl btn-neon text-xs font-bold uppercase tracking-widest flex items-center gap-2 whitespace-nowrap"
          >
            <Video size={16} />
            <span>{t('projects.cta.button')}</span>
          </button>
        </div>
      </div>

      {/* Lightbox */}
      {activeLightbox && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 md:p-10 animate-in fade-in duration-300">
          <div className="absolute top-6 right-6 z-10 flex items-center gap-4">
            <span className="text-xs font-mono text-[#00FF66] bg-black border border-[#00FF66]/40 px-3 py-1 rounded-full uppercase">
              {t('projects.lightboxBadge')}
            </span>
            <button
              onClick={() => {
                soundFx.playClick();
                setActiveLightbox(null);
              }}
              className="p-3 rounded-full bg-white/10 hover:bg-[#00FF66] text-white hover:text-black transition-all"
            >
              <X size={24} />
            </button>
          </div>

          <div className="max-w-5xl w-full max-h-[90vh] overflow-y-auto bg-[#080d0a] border border-[#00FF66]/40 rounded-2xl shadow-[0_0_50px_rgba(0,255,102,0.2)] overflow-hidden">
            <div className="relative aspect-video w-full bg-black">
              {activeLightbox.youtubeId ? (
                <iframe
                  className="w-full h-full"
                  src={`https://www.youtube.com/embed/${activeLightbox.youtubeId}?autoplay=1&rel=0`}
                  title={activeLightbox.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : activeLightbox.videoUrl ? (
                <video autoPlay controls loop className="w-full h-full object-contain bg-black" src={activeLightbox.videoUrl} poster={activeLightbox.imageUrl} />
              ) : (
                <img src={activeLightbox.imageUrl} alt={activeLightbox.title} className="w-full h-full object-contain bg-black" />
              )}
            </div>

            <div className="p-8">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-white/10">
                <div>
                  <span className="text-xs font-mono text-[#00FF66] uppercase tracking-widest block mb-1">
                    {activeLightbox.clientOrArtist} • {activeLightbox.category}
                  </span>
                  <h2 className="text-2xl sm:text-4xl font-heading font-extrabold uppercase text-white">{activeLightbox.title}</h2>
                </div>
                <div className="flex items-center gap-3">
                  {activeLightbox.youtubePlaylistUrl && (
                    <a
                      href={activeLightbox.youtubePlaylistUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-xs font-extrabold text-black bg-[#00FF66] hover:bg-[#00cc52] px-4 py-2 rounded-xl transition-all shadow-[0_0_15px_rgba(0,255,102,0.7)] uppercase tracking-wider"
                    >
                      <span>{t('experience.watchPlaylist')}</span>
                      <ExternalLink size={14} />
                    </a>
                  )}
                  <div className="text-sm font-mono text-[#00FF66] bg-[#0D5C2A]/30 px-4 py-2 rounded-xl border border-[#00FF66]/40">
                    {t('projects.yearReleased')} {activeLightbox.year}
                  </div>
                </div>
              </div>

              <div className="py-6 space-y-4">
                <h4 className="text-xs font-mono uppercase text-[#A0A0A0] tracking-widest">{t('projects.projectOverview')}</h4>
                <p className="text-base sm:text-lg text-white/90 leading-relaxed">{activeLightbox.description}</p>
                <div className="pt-4 flex flex-wrap gap-2">
                  {activeLightbox.tags.map((tag, i) => (
                    <span key={i} className="text-xs font-semibold px-3 py-1 rounded-lg bg-[#0D5C2A]/50 text-[#00FF66] border border-[#00FF66]/30">
                      ★ {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-6 border-t border-white/10 flex items-center justify-between">
                <span className="text-xs text-[#A0A0A0]/60 font-mono">{t('projects.directedBy')}</span>
                <button
                  onClick={() => {
                    setActiveLightbox(null);
                    onOpenBooking();
                  }}
                  className="px-5 py-2.5 rounded-lg btn-neon text-xs font-bold uppercase tracking-wider"
                >
                  {t('projects.requestTreatment')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
