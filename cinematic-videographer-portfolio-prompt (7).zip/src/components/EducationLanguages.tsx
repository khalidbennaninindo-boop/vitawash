import React from 'react';
import { useTranslation } from 'react-i18next';
import { EDUCATION_ITEMS, LANGUAGES_DATA } from '../data/portfolioData';
import { GraduationCap, Globe, Award, CheckCircle, Sparkles } from 'lucide-react';
import { soundFx } from '../utils/audioFx';

const LANGUAGE_KEYS = ['arabic', 'french', 'english'];
const LEVEL_KEYS: Record<string, string> = { Native: 'native', Professional: 'professional' };

export const EducationLanguages: React.FC = () => {
  const { t } = useTranslation();

  return (
    <section id="education" className="relative py-28 bg-black border-t border-white/5 overflow-hidden">
      <div className="absolute bottom-10 right-1/4 w-[400px] h-[400px] bg-[#0D5C2A]/15 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Education */}
          <div className="lg:col-span-7 space-y-8">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase text-[#00FF66] tracking-[0.25em] mb-2">
                <span className="w-8 h-[1px] bg-[#00FF66]" />
                <span>{t('education.badge')}</span>
              </div>
              <h2 className="text-3xl sm:text-5xl font-heading font-extrabold uppercase tracking-tight text-white flex items-center gap-3">
                <GraduationCap className="text-[#00FF66]" size={42} />
                <span>{t('education.title')} <span className="text-[#00FF66]">{t('education.titleAccent')}</span></span>
              </h2>
            </div>

            <div className="space-y-4">
              {EDUCATION_ITEMS.map((item, idx) => (
                <div
                  key={idx}
                  onMouseEnter={() => soundFx.playHover()}
                  onClick={() => soundFx.playClick()}
                  className="p-6 md:p-8 rounded-2xl glass-panel border border-white/10 hover:border-[#00FF66] transition-all duration-300 group flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3.5 rounded-xl bg-black border border-[#00FF66]/30 group-hover:bg-[#00FF66]/10 text-[#00FF66] transition-all">
                      <Award size={24} />
                    </div>
                    <div>
                      <span className="text-xs font-mono text-[#00FF66] uppercase tracking-wider block mb-1">
                        {item.institution}
                      </span>
                      <h3 className="text-xl font-heading font-extrabold text-white group-hover:text-[#00FF66] transition-colors uppercase">
                        {item.degree}
                      </h3>
                      {item.year && <p className="text-xs text-[#A0A0A0] mt-1 font-mono">{item.year}</p>}
                    </div>
                  </div>
                  <div className="sm:text-right flex items-center sm:flex-col justify-between sm:justify-center gap-2">
                    <span className="text-xs font-mono uppercase px-3 py-1 rounded-full bg-[#0D5C2A]/40 text-[#00FF66] border border-[#00FF66]/30 flex items-center gap-1">
                      <CheckCircle size={12} />
                      {item.badge}
                    </span>
                    <span className="text-[10px] text-[#A0A0A0]/70 font-mono hidden sm:block">
                      {t('education.verified')}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0D5C2A]/30 to-black border border-[#00FF66]/30 flex items-center gap-4">
              <Sparkles className="text-[#00FF66] flex-shrink-0" size={28} />
              <p className="text-xs sm:text-sm text-white/90 leading-relaxed">{t('education.continuousDev')}</p>
            </div>
          </div>

          {/* Languages */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase text-[#00FF66] tracking-[0.25em] mb-2">
                <span className="w-8 h-[1px] bg-[#00FF66]" />
                <span>{t('languages.badge')}</span>
              </div>
              <h2 className="text-3xl sm:text-5xl font-heading font-extrabold uppercase tracking-tight text-white flex items-center gap-3">
                <Globe className="text-[#00FF66]" size={42} />
                <span><span className="text-[#00FF66]">{t('languages.titleAccent')}</span></span>
              </h2>
            </div>

            <div className="p-8 rounded-3xl glass-card border border-[#00FF66]/30 space-y-7 shadow-2xl">
              <p className="text-xs font-mono text-[#A0A0A0] leading-relaxed uppercase tracking-wider border-b border-white/10 pb-4">
                {t('languages.description')}
              </p>

              <div className="space-y-6">
                {LANGUAGES_DATA.map((lang, idx) => (
                  <div key={idx} className="space-y-2 group">
                    <div className="flex justify-between items-center text-sm font-bold uppercase tracking-wider">
                      <span className="text-white group-hover:text-[#00FF66] transition-colors flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-[#00FF66] shadow-[0_0_6px_#00FF66]" />
                        {t(`languages.names.${LANGUAGE_KEYS[idx]}`, lang.name)}
                      </span>
                      <span className="text-xs font-mono text-[#00FF66] bg-black px-2.5 py-0.5 rounded border border-[#00FF66]/30">
                        {t(`languages.levels.${LEVEL_KEYS[lang.level] || 'basic'}`, lang.level)}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-black/80 rounded-full overflow-hidden border border-white/10 p-0.5">
                      <div
                        className="h-full bg-gradient-to-r from-[#0D5C2A] to-[#00FF66] rounded-full shadow-[0_0_12px_rgba(0,255,102,0.8)] transition-all duration-1000 group-hover:brightness-125"
                        style={{ width: `${lang.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-white/10 text-center">
                <span className="text-[11px] font-mono text-[#A0A0A0]/80 uppercase">{t('languages.ready')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
