import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Film, Video, Camera, Sparkles, MapPin, Award, CheckCircle2, FileText, ArrowUpRight } from 'lucide-react';
import { soundFx } from '../utils/audioFx';
import { useScrollReveal } from '../hooks/useScrollReveal';
import { SectionHeading } from './SectionHeading';

interface Props {
  onOpenCV: () => void;
  onOpenBooking: () => void;
}

const DOMAIN_KEYS = [
  'filmFestivals', 'musicVideos', 'commercials', 'luxury',
  'social', 'photography', 'motion', 'postProduction'
];

const DOMAIN_ICONS = [Film, Video, Camera, Sparkles, Film, Video, Camera, Sparkles];

export const About: React.FC<Props> = ({ onOpenCV, onOpenBooking }) => {
  const { t } = useTranslation();
  const [selectedDomain, setSelectedDomain] = useState<number | null>(null);
  const { ref, visible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="about" className="relative py-28 bg-black overflow-hidden border-t border-white/5">
      <div className="absolute top-1/2 right-0 w-[450px] h-[450px] bg-[#0D5C2A]/15 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          badge={t('about.badge')}
          title={t('about.title')}
          accent={t('about.titleAccent')}
        />

        <div ref={ref} className={`grid grid-cols-1 lg:grid-cols-12 gap-12 items-center transition-all duration-1000 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          {/* Portrait */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              <div className="absolute -inset-2 bg-gradient-to-br from-[#00FF66]/30 via-transparent to-[#0D5C2A]/40 rounded-3xl blur-xl opacity-75" />
              <div className="relative rounded-2xl overflow-hidden glass-panel border border-white/10 group">
                <div className="aspect-[4/5] relative overflow-hidden bg-[#0a0f0c]">
                  <img
                    src="https://images.pexels.com/photos/23384400/pexels-photo-23384400.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900"
                    alt="Mohammed Belhouari"
                    className="w-full h-full object-cover filter contrast-125 saturate-[0.8] group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-90" />

                  <div className="absolute top-4 left-4 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/70 backdrop-blur-md border border-[#00FF66]/40 text-xs font-mono text-white">
                    <MapPin size={12} className="text-[#00FF66]" />
                    <span>Rabat, Morocco</span>
                  </div>

                  <div className="absolute bottom-6 left-6 right-6 p-5 rounded-xl bg-black/85 backdrop-blur-md border border-[#00FF66]/30 shadow-2xl">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-[#0D5C2A]/50 border border-[#00FF66] flex items-center justify-center text-[#00FF66]">
                        <Award size={22} />
                      </div>
                      <div>
                        <h4 className="text-sm font-heading font-extrabold text-white uppercase tracking-wider">
                          {t('about.yearsMastery')}
                        </h4>
                        <p className="text-xs text-[#A0A0A0] mt-0.5">{t('about.directingFilmingGrading')}</p>
                      </div>
                    </div>
                    <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
                      <button
                        onClick={() => {
                          soundFx.playClick();
                          onOpenCV();
                        }}
                        className="text-xs text-[#00FF66] font-mono hover:underline flex items-center gap-1"
                      >
                        <FileText size={13} />
                        <span>{t('about.viewCV')}</span>
                        <ArrowUpRight size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bio + Domains */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-4">
              <p className="text-xl sm:text-2xl font-semibold text-white leading-snug tracking-wide">
                {t('about.bio1')}
              </p>
              <p
                className="text-base sm:text-lg text-[#A0A0A0] leading-relaxed"
                dangerouslySetInnerHTML={{ __html: t('about.bio2') }}
              />
            </div>

            <div>
              <h3 className="text-xs font-mono text-[#00FF66] uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                <span>{t('about.specializations')}</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {DOMAIN_KEYS.map((key, index) => {
                  const isSelected = selectedDomain === index;
                  const Icon = DOMAIN_ICONS[index];
                  return (
                    <div
                      key={key}
                      onClick={() => {
                        soundFx.playClick();
                        setSelectedDomain(isSelected ? null : index);
                      }}
                      className={`p-4 rounded-xl cursor-pointer transition-all duration-300 border ${
                        isSelected
                          ? 'bg-[#0D5C2A]/40 border-[#00FF66] shadow-[0_0_20px_rgba(0,255,102,0.25)]'
                          : 'glass-panel hover:bg-white/5 border-white/10 hover:border-[#00FF66]/40'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-black border border-white/10">
                            <Icon size={18} className="text-[#00FF66]" />
                          </div>
                          <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                            {t(`about.domains.${key}.title`)}
                          </h4>
                        </div>
                        <CheckCircle2
                          size={16}
                          className={`mt-1 transition-colors ${isSelected ? 'text-[#00FF66]' : 'text-white/20'}`}
                        />
                      </div>
                      {isSelected && (
                        <div className="mt-3 pt-3 border-t border-white/10 text-xs text-[#A0A0A0] leading-relaxed animate-in fade-in duration-200">
                          <span className="text-[#00FF66] font-mono mr-1">► {t('about.focus')}</span>
                          {t(`about.domains.${key}.desc`)}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 flex flex-wrap items-center gap-4 border-t border-white/10">
              <button
                onClick={() => {
                  soundFx.playClick();
                  onOpenCV();
                }}
                className="px-6 py-3 rounded-xl btn-neon text-xs font-bold uppercase tracking-wider flex items-center gap-2"
              >
                <FileText size={15} />
                <span>{t('about.downloadCV')}</span>
              </button>
              <button
                onClick={() => {
                  soundFx.playClick();
                  onOpenBooking();
                }}
                className="px-6 py-3 rounded-xl btn-outline-neon text-xs font-bold uppercase tracking-wider"
              >
                {t('about.startConversation')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
