import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Globe } from 'lucide-react';
import { soundFx } from '../utils/audioFx';

const LANGUAGES = [
  { code: 'en', label: 'EN', name: 'English' },
  { code: 'fr', label: 'FR', name: 'Français' },
  { code: 'ar', label: 'AR', name: 'العربية' },
];

// Applies document direction + persists the chosen language
function applyLanguage(lng: string) {
  if (typeof document === 'undefined') return;
  const dir = lng === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.setAttribute('dir', dir);
  document.documentElement.setAttribute('lang', lng);
  try {
    localStorage.setItem('mb_lang', lng);
  } catch {
    /* ignore */
  }
}

export const LanguageSwitcher: React.FC = () => {
  const { i18n } = useTranslation();
  const current = i18n.language?.startsWith('ar') ? 'ar' : i18n.language?.startsWith('fr') ? 'fr' : 'en';

  // Restore saved language on first mount
  useEffect(() => {
    let saved: string | null = null;
    try {
      saved = localStorage.getItem('mb_lang');
    } catch {
      /* ignore */
    }
    if (saved && ['en', 'fr', 'ar'].includes(saved) && saved !== i18n.language) {
      i18n.changeLanguage(saved);
    }
    applyLanguage(i18n.language || 'en');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Keep direction in sync whenever language changes
  useEffect(() => {
    applyLanguage(i18n.language || 'en');
  }, [i18n.language]);

  const handleChange = (code: string) => {
    soundFx.playClick();
    i18n.changeLanguage(code);
    applyLanguage(code);
  };

  return (
    <div className="flex items-center gap-1 p-1 rounded-xl bg-black/60 border border-white/10 backdrop-blur-md" role="group" aria-label="Language">
      <Globe size={14} className="text-[#00FF66] mx-1.5" />
      {LANGUAGES.map((lang) => {
        const isActive = current === lang.code;
        return (
          <button
            key={lang.code}
            onClick={() => handleChange(lang.code)}
            onMouseEnter={() => soundFx.playHover()}
            title={lang.name}
            aria-pressed={isActive}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold font-mono tracking-wider uppercase transition-all duration-300 ${
              isActive
                ? 'bg-[#00FF66] text-black shadow-[0_0_12px_rgba(0,255,102,0.5)]'
                : 'text-[#A0A0A0] hover:text-white'
            }`}
          >
            {lang.label}
          </button>
        );
      })}
    </div>
  );
};
