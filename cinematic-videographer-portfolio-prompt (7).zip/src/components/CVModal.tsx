import React from 'react';
import { useTranslation } from 'react-i18next';
import { X, Printer, MapPin, Phone, Mail, Check } from 'lucide-react';
import { HERO_DATA, EXPERIENCE_ITEMS, SKILL_CATEGORIES, EDUCATION_ITEMS, LANGUAGES_DATA, CONTACT_DATA } from '../data/portfolioData';
import { soundFx } from '../utils/audioFx';
import confetti from 'canvas-confetti';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const LANGUAGE_KEYS = ['arabic', 'french', 'english'];

export const CVModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();
  if (!isOpen) return null;

  const handlePrint = () => {
    soundFx.playSuccess();
    confetti({ particleCount: 50, spread: 60, origin: { y: 0.5 }, colors: ['#00FF66', '#FFFFFF'] });
    window.print();
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
      <div className="relative max-w-4xl w-full bg-[#070b09] border border-[#00FF66]/50 rounded-3xl shadow-[0_0_50px_rgba(0,255,102,0.25)] my-8 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-4 sm:p-6 bg-black border-b border-white/10 flex items-center justify-between sticky top-0 z-20">
          <span className="text-sm font-bold font-mono uppercase text-white tracking-widest flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-[#00FF66] animate-pulse" />
            {t('cv.official')}
          </span>
          <div className="flex items-center gap-3">
            <button onClick={handlePrint} className="px-4 py-2 rounded-xl btn-neon text-xs font-bold uppercase flex items-center gap-2 shadow-lg">
              <Printer size={15} />
              <span>{t('cv.printDownload')}</span>
            </button>
            <button onClick={() => { soundFx.playClick(); onClose(); }} className="p-2 rounded-xl bg-white/10 hover:bg-[#00FF66] text-white hover:text-black transition-colors">
              <X size={20} />
            </button>
          </div>
        </div>

        <div className="p-6 sm:p-12 overflow-y-auto space-y-10 text-left text-white">
          {/* Header */}
          <div className="border-b border-[#00FF66]/30 pb-8 flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-3xl sm:text-5xl font-heading font-extrabold uppercase text-white text-glow">{HERO_DATA.name}</h1>
              <h2 className="text-base sm:text-xl font-bold text-[#00FF66] uppercase tracking-wider mt-2">{HERO_DATA.title}</h2>
              <p className="text-xs font-mono text-[#A0A0A0] mt-3 max-w-2xl leading-relaxed">{HERO_DATA.shortIntro}</p>
            </div>
            <div className="text-xs font-mono space-y-2 text-[#A0A0A0] border-l border-white/10 pl-4">
              <div className="flex items-center gap-2"><MapPin size={14} className="text-[#00FF66]" /><span className="text-white">{CONTACT_DATA.address}</span></div>
              <div className="flex items-center gap-2"><Phone size={14} className="text-[#00FF66]" /><span className="text-white">{CONTACT_DATA.phone}</span></div>
              <div className="flex items-center gap-2"><Mail size={14} className="text-[#00FF66]" /><span className="text-white">{CONTACT_DATA.email}</span></div>
            </div>
          </div>

          {/* Experience */}
          <div className="space-y-6">
            <h3 className="text-sm font-mono font-extrabold uppercase text-[#00FF66] tracking-[0.2em] border-b border-white/10 pb-2">{t('cv.experience')}</h3>
            <div className="space-y-6">
              {EXPERIENCE_ITEMS.map((exp) => (
                <div key={exp.id} className="p-5 rounded-2xl bg-black/60 border border-white/10 space-y-2">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <h4 className="text-lg font-heading font-bold text-white uppercase">{exp.company}</h4>
                      {exp.subTitle && <span className="text-xs font-mono px-2 py-0.5 bg-[#0D5C2A] text-white rounded">{exp.subTitle}</span>}
                    </div>
                    <span className="text-xs font-mono font-semibold text-[#00FF66]">{exp.period}</span>
                  </div>
                  <div className="text-sm font-semibold text-[#A0A0A0]">{t('cv.role')} {exp.role} {exp.location ? `• ${exp.location}` : ''}</div>
                  {exp.description && <p className="text-xs text-white/80 italic leading-relaxed pt-1">{exp.description}</p>}
                  <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {exp.responsibilities?.map((item, i) => (
                      <div key={i} className="text-xs text-white/85 flex items-center gap-2">
                        <span className="text-[#00FF66]">▪</span>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Skills */}
          <div className="space-y-6">
            <h3 className="text-sm font-mono font-extrabold uppercase text-[#00FF66] tracking-[0.2em] border-b border-white/10 pb-2">{t('cv.skills')}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {SKILL_CATEGORIES.map((cat, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-black/60 border border-white/10">
                  <h5 className="text-xs font-mono font-bold text-[#00FF66] uppercase mb-2">{cat.title}</h5>
                  <div className="space-y-1">
                    {cat.items.map((item, i) => (
                      <div key={i} className="flex items-center gap-1.5 text-xs text-white">
                        <Check size={12} className="text-[#00FF66]" />
                        <span>{item.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Education & Languages */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-white/10">
            <div className="space-y-4">
              <h3 className="text-sm font-mono font-extrabold uppercase text-[#00FF66] tracking-[0.2em]">{t('cv.education')}</h3>
              <div className="space-y-3">
                {EDUCATION_ITEMS.map((edu, i) => (
                  <div key={i} className="p-3.5 rounded-xl bg-black/50 border border-white/10">
                    <strong className="text-sm text-white block uppercase">{edu.degree}</strong>
                    <span className="text-xs text-[#00FF66] font-mono block">{edu.institution}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="text-sm font-mono font-extrabold uppercase text-[#00FF66] tracking-[0.2em]">{t('cv.linguistic')}</h3>
              <div className="grid grid-cols-2 gap-3">
                {LANGUAGES_DATA.map((lang, i) => (
                  <div key={i} className="p-3.5 rounded-xl bg-black/50 border border-white/10 text-center">
                    <strong className="text-sm text-white block">{t(`languages.names.${LANGUAGE_KEYS[i]}`, lang.name)}</strong>
                    <span className="text-xs font-mono text-[#00FF66] block mt-1">{t(`languages.levels.${lang.level === 'Native' ? 'native' : 'professional'}`, lang.level)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="text-center pt-8 border-t border-white/10 text-[11px] font-mono text-[#A0A0A0]/60">{t('cv.confidential')}</div>
        </div>
      </div>
    </div>
  );
};
