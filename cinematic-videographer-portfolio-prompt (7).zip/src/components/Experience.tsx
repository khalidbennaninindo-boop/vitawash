import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { EXPERIENCE_ITEMS } from '../data/portfolioData';
import { MapPin, ChevronDown, ChevronUp, Star, Award, ExternalLink } from 'lucide-react';
import { soundFx } from '../utils/audioFx';
import { SectionHeading } from './SectionHeading';

export const Experience: React.FC = () => {
  const { t } = useTranslation();
  const [expandedIds, setExpandedIds] = useState<string[]>(['exp-1', 'exp-2', 'exp-3', 'exp-4']);

  const toggleExpand = (id: string) => {
    soundFx.playClick();
    if (expandedIds.includes(id)) {
      setExpandedIds(expandedIds.filter((i) => i !== id));
    } else {
      setExpandedIds([...expandedIds, id]);
    }
  };

  const expandAll = () => {
    soundFx.playClick();
    setExpandedIds(EXPERIENCE_ITEMS.map((i) => i.id));
  };

  return (
    <section id="experience" className="relative py-28 bg-black border-t border-white/5 overflow-hidden">
      <div className="absolute top-1/4 right-10 w-[500px] h-[500px] bg-[#0D5C2A]/10 rounded-full blur-[180px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-14 gap-6">
          <SectionHeading
            badge={t('experience.badge')}
            title={t('experience.title')}
            accent={t('experience.titleAccent')}
          />
          <button
            onClick={expandAll}
            className="px-4 py-2 text-xs font-mono rounded-lg btn-outline-neon uppercase tracking-wider flex items-center gap-1.5"
          >
            <span>{t('experience.expandAll')}</span>
            <ChevronDown size={14} />
          </button>
        </div>

        <div className="relative border-l-2 border-[#0D5C2A] ml-4 md:ml-36 space-y-12">
          {EXPERIENCE_ITEMS.map((exp) => {
            const isExpanded = expandedIds.includes(exp.id);
            const isCurrent = exp.period.toLowerCase().includes('present') || exp.company === 'DONE';

            return (
              <div key={exp.id} className="relative pl-8 md:pl-12 group">
                {/* Timeline dot */}
                <div
                  className={`absolute -left-[11px] top-1 w-5 h-5 rounded-full border-2 transition-all duration-300 ${
                    isCurrent
                      ? 'bg-[#00FF66] border-black shadow-[0_0_15px_#00FF66] scale-125'
                      : 'bg-black border-[#00FF66] group-hover:bg-[#00FF66] group-hover:shadow-[0_0_10px_#00FF66]'
                  }`}
                >
                  {isCurrent && <div className="w-1.5 h-1.5 rounded-full bg-black animate-ping" />}
                </div>

                {/* Period timestamp */}
                <div className="hidden md:block absolute -left-36 top-1 w-28 text-right font-mono text-xs font-bold text-[#A0A0A0] group-hover:text-[#00FF66] transition-colors pr-3">
                  <span className="block">{exp.period}</span>
                </div>

                {/* Card */}
                <div
                  onClick={() => toggleExpand(exp.id)}
                  onMouseEnter={() => soundFx.playHover()}
                  className={`p-6 md:p-8 rounded-2xl transition-all duration-300 cursor-pointer border ${
                    isCurrent
                      ? 'glass-card border-[#00FF66]/50 shadow-[0_10px_35px_-5px_rgba(0,255,102,0.15)]'
                      : 'glass-panel hover:bg-white/5 border-white/10 hover:border-[#00FF66]/40'
                  } ${exp.imageUrl ? 'md:grid md:grid-cols-3 md:gap-8' : ''}`}
                >
                  {/* Poster */}
                  {exp.imageUrl && (
                    <div className="hidden md:flex md:col-span-1 flex-col items-center justify-start group/poster" onClick={(e) => e.stopPropagation()}>
                      <div className="relative w-full max-w-[220px] aspect-[2/3] overflow-hidden rounded-2xl border-2 border-[#00FF66]/40 shadow-[0_0_30px_rgba(0,255,102,0.25)] group-hover/poster:shadow-[0_0_45px_rgba(0,255,102,0.6)] transition-all duration-500 group-hover/poster:-translate-y-1 group-hover/poster:scale-[1.02]">
                        <img src={exp.imageUrl} alt={exp.company} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
                        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/80 border border-[#00FF66]/60 text-[8px] font-mono text-[#00FF66] font-bold uppercase tracking-wider">
                          {t('experience.officialPoster')}
                        </div>
                      </div>
                    </div>
                  )}

                  <div className={exp.imageUrl ? 'md:col-span-2' : ''}>
                    {/* Header */}
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                      <div>
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <span className="md:hidden font-mono text-xs text-[#00FF66] bg-[#0D5C2A]/30 px-2.5 py-0.5 rounded">
                            {exp.period}
                          </span>
                          {isCurrent && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-mono uppercase font-bold bg-[#00FF66] text-black px-2 py-0.5 rounded shadow-[0_0_10px_rgba(0,255,102,0.5)]">
                              <span className="w-1.5 h-1.5 rounded-full bg-black animate-pulse" />
                              {t('experience.currentPosition')}
                            </span>
                          )}
                          {exp.subTitle && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase text-[#00FF66] bg-black border border-[#00FF66]/50 px-2.5 py-0.5 rounded">
                              <Star size={12} className="fill-[#00FF66]" />
                              {exp.subTitle}
                            </span>
                          )}
                        </div>
                        <h3 className="text-2xl font-heading font-extrabold text-white uppercase tracking-tight group-hover:text-[#00FF66] transition-colors">
                          {exp.company}
                        </h3>
                        <h4 className="text-sm md:text-base font-bold text-[#A0A0A0] uppercase tracking-wider mt-1">
                          {exp.role}
                        </h4>
                      </div>

                      <div className="flex items-center gap-3 text-xs text-[#A0A0A0]/70 font-mono">
                        {exp.location && (
                          <span className="flex items-center gap-1 bg-black/60 px-2.5 py-1 rounded border border-white/5">
                            <MapPin size={13} className="text-[#00FF66]" />
                            {exp.location}
                          </span>
                        )}
                        <button
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-[#00FF66]/20 text-white hover:text-[#00FF66] transition-colors"
                          title={isExpanded ? 'Collapse' : 'Expand'}
                        >
                          {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                        </button>
                      </div>
                    </div>

                    {exp.description && (
                      <p className="text-sm md:text-base text-white/90 leading-relaxed italic mb-4 p-3.5 rounded-xl bg-black/50 border border-white/5">
                        &ldquo;{exp.description}&rdquo;
                      </p>
                    )}

                    {isExpanded && (
                      <div className="mt-5 pt-5 border-t border-white/10 animate-in fade-in slide-in-from-top duration-300">
                        {/* YouTube embed */}
                        {exp.youtubeId && (
                          <div className="mb-6 p-4 md:p-5 rounded-2xl bg-black/90 border border-[#00FF66]/50 shadow-[0_0_25px_rgba(0,255,102,0.2)] space-y-3.5" onClick={(e) => e.stopPropagation()}>
                            <div className="flex flex-wrap items-center justify-between gap-3">
                              <span className="text-xs font-mono uppercase text-[#00FF66] font-bold flex items-center gap-2">
                                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                                ► {t('experience.officialVideoRelease')} {exp.mediaTitle || ''}
                              </span>
                              {exp.youtubePlaylistUrl && (
                                <a
                                  href={exp.youtubePlaylistUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1.5 text-xs font-extrabold text-black bg-[#00FF66] hover:bg-[#00cc52] px-3.5 py-1.5 rounded-xl transition-all shadow-[0_0_15px_rgba(0,255,102,0.7)] uppercase tracking-wider"
                                >
                                  <span>{t('experience.watchPlaylist')}</span>
                                  <ExternalLink size={14} />
                                </a>
                              )}
                            </div>
                            <div className="relative aspect-video w-full rounded-xl overflow-hidden border border-white/15 bg-black">
                              <iframe
                                className="w-full h-full"
                                src={`https://www.youtube.com/embed/${exp.youtubeId}?rel=0`}
                                title={exp.mediaTitle || 'YouTube video'}
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen
                              />
                            </div>
                          </div>
                        )}

                        {exp.featuredWork && (
                          <div className="mb-4">
                            <span className="text-[11px] font-mono uppercase text-[#00FF66] tracking-widest block mb-2 flex items-center gap-1.5">
                              <Award size={13} /> {t('experience.featuredCollaborations')}
                            </span>
                            <div className="flex flex-wrap gap-2">
                              {exp.featuredWork.map((work, idx) => (
                                <span key={idx} className="text-xs font-semibold px-3 py-1 rounded-lg bg-[#0D5C2A]/40 text-white border border-[#00FF66]/40 shadow-[0_0_10px_rgba(0,255,102,0.15)]">
                                  ★ {work}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        <h5 className="text-xs font-mono uppercase text-[#A0A0A0] tracking-widest mb-3">
                          {t('experience.responsibilities')}
                        </h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          {exp.responsibilities?.map((item, respIdx) => (
                            <div key={respIdx} className="flex items-start gap-2.5 text-xs md:text-sm text-white/85 py-1">
                              <span className="text-[#00FF66] mt-0.5 font-bold">►</span>
                              <span>{item}</span>
                            </div>
                          ))}
                        </div>

                        {exp.highlights && (
                          <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 text-xs font-mono text-[#00FF66]/90">
                            <span>✓ HIGHLIGHT:</span>
                            <span>{exp.highlights[0]}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Mobile poster */}
                    {exp.imageUrl && (
                      <div className="md:hidden mt-5 flex items-center gap-4 p-3 rounded-2xl bg-black/60 border border-[#00FF66]/30" onClick={(e) => e.stopPropagation()}>
                        <div className="relative w-20 h-28 flex-shrink-0 overflow-hidden rounded-xl border border-[#00FF66]/40 shadow-[0_0_15px_rgba(0,255,102,0.25)]">
                          <img src={exp.imageUrl} alt={exp.company} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <span className="text-[10px] font-mono uppercase text-[#00FF66] tracking-widest block">{t('experience.officialPoster')}</span>
                          <span className="text-xs text-white font-bold block mt-1">{t('experience.featuredCinema')}</span>
                        </div>
                      </div>
                    )}

                    {!isExpanded && (
                      <div className="mt-2 text-xs font-mono text-[#A0A0A0]/50 hover:text-[#00FF66] transition-colors flex items-center gap-1">
                        <span>{t('experience.clickToShow')} {exp.responsibilities?.length || 0} {t('experience.productionResponsibilities')}</span>
                        <span>→</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
