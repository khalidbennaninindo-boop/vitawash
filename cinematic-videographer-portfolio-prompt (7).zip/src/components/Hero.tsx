import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { HERO_DATA } from '../data/portfolioData';
import { ArrowRight, Video, Camera, Film } from 'lucide-react';
import { soundFx } from '../utils/audioFx';

interface Props {
  onExploreProjects: () => void;
  onContact: () => void;
  onOpenBooking: () => void;
}

const StatCard: React.FC<{ value: string; label: string }> = ({ value, label }) => (
  <div className="p-5 rounded-xl glass-panel border border-white/5 flex flex-col items-center justify-center relative overflow-hidden group hover:border-[#00FF66]/40 transition-all duration-500">
    <div className="absolute top-0 left-0 w-1 h-full bg-[#00FF66]/50 group-hover:w-full group-hover:opacity-10 transition-all duration-500" />
    <span className="text-3xl md:text-4xl font-heading font-extrabold text-white group-hover:text-[#00FF66] transition-colors">
      {value}
    </span>
    <span className="text-xs text-[#A0A0A0] uppercase font-mono tracking-widest mt-1 text-center">
      {label}
    </span>
  </div>
);

export const Hero: React.FC<Props> = ({ onExploreProjects, onContact, onOpenBooking }) => {
  const { t } = useTranslation();
  const [isVideoPlaying, setIsVideoPlaying] = useState(true);
  const titleParts = t('hero.title').split('•');

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black pt-20 pb-12">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#00FF66]/10 rounded-full blur-[140px] animate-pulse" />
        <div className="absolute bottom-1/3 right-1/4 w-[500px] h-[500px] bg-[#0D5C2A]/20 rounded-full blur-[180px]" />

        {isVideoPlaying ? (
          <video
            autoPlay loop muted playsInline
            className="w-full h-full object-cover opacity-35 scale-105 transition-all duration-1000 filter brightness-[0.7] contrast-125"
            src={HERO_DATA.heroVideoUrl}
            poster={HERO_DATA.heroBgImage}
          />
        ) : (
          <div
            className="w-full h-full bg-cover bg-center opacity-30 scale-105 transition-transform duration-1000 filter contrast-125"
            style={{ backgroundImage: `url('${HERO_DATA.heroBgImage}')` }}
          />
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-black/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-black/80" />
      </div>

      {/* Viewfinder overlay */}
      <div className="absolute top-24 left-6 md:left-12 z-10 font-mono text-[11px] text-[#A0A0A0]/60 hidden md:flex items-center gap-4">
        <span
          onClick={() => {
            soundFx.playClick();
            onOpenBooking();
          }}
          className="flex items-center gap-1.5 text-white bg-black/80 border border-[#00FF66]/50 px-3 py-1 rounded cursor-pointer hover:bg-[#0D5C2A]/40 hover:text-[#00FF66] transition-all duration-300 shadow-[0_0_10px_rgba(0,255,102,0.2)]"
        >
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
          {t('hero.recBadge')}
        </span>
        <span className="text-[#00FF66]">ISO 800</span>
        <span>24 FPS</span>
        <span>SHUTTER 1/48</span>
        <span>WB 5600K</span>
      </div>

      {/* Media toggle */}
      <div className="absolute top-24 right-6 md:right-12 z-10 hidden sm:flex items-center gap-2 font-mono text-xs">
        <button
          onClick={() => {
            setIsVideoPlaying(!isVideoPlaying);
            soundFx.playClick();
          }}
          className="px-3 py-1 bg-black/70 border border-white/10 hover:border-[#00FF66]/50 rounded text-white/80 hover:text-white flex items-center gap-2 transition-all"
        >
          <Film size={12} className="text-[#00FF66]" />
          <span>{isVideoPlaying ? 'BG VIDEO: ON' : 'BG VIDEO: OFF'}</span>
        </button>
      </div>

      {/* Main content */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center justify-center my-auto">
        {/* Badge */}
        <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-[#0D5C2A]/35 border border-[#00FF66]/40 mb-6 text-xs md:text-sm text-white shadow-[0_0_25px_rgba(0,255,102,0.15)] backdrop-blur-md animate-in fade-in slide-in-from-bottom duration-700">
          <span className="w-2 h-2 rounded-full bg-[#00FF66] animate-neon-pulse shadow-[0_0_8px_#00FF66]" />
          <span className="font-semibold tracking-wider text-glow">{t('hero.badge')}</span>
          <span className="text-[#00FF66] font-mono">• {t('hero.badgeAvailable')}</span>
        </div>

        {/* Name */}
        <h1 className="text-4xl sm:text-6xl lg:text-8xl font-heading font-extrabold tracking-tighter uppercase text-white mb-3 text-glow transition-transform hover:scale-[1.01]">
          MOHAMMED <span className="text-[#00FF66] font-normal underline decoration-[#0D5C2A] decoration-4 underline-offset-8">BELHOUARI</span>
        </h1>

        {/* Title */}
        <div className="flex flex-wrap items-center justify-center gap-3 md:gap-5 text-base md:text-2xl font-bold tracking-[0.2em] text-white uppercase mt-4 mb-8">
          <span className="text-white">{titleParts[0]}</span>
          <span className="text-[#00FF66]">•</span>
          <span className="text-white">{titleParts[1]}</span>
          <span className="text-[#00FF66]">•</span>
          <span className="text-[#A0A0A0]">{titleParts[2]}</span>
        </div>

        {/* Intro */}
        <div className="max-w-3xl mb-10 p-6 rounded-2xl glass-panel relative">
          <p className="text-[#A0A0A0] text-base md:text-lg leading-relaxed font-normal italic">
            &ldquo;{t('hero.intro')}&rdquo;
          </p>
        </div>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center gap-5 mb-16 w-full max-w-md justify-center">
          <button
            onClick={() => {
              soundFx.playClick();
              onExploreProjects();
            }}
            onMouseEnter={() => soundFx.playHover()}
            className="w-full sm:w-auto px-8 py-4 rounded-xl btn-neon text-base uppercase tracking-widest flex items-center justify-center gap-3 group"
          >
            <Video size={18} className="group-hover:rotate-12 transition-transform" />
            <span>{t('hero.viewPortfolio')}</span>
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => {
              soundFx.playClick();
              onContact();
            }}
            onMouseEnter={() => soundFx.playHover()}
            className="w-full sm:w-auto px-8 py-4 rounded-xl btn-outline-neon text-base uppercase tracking-widest flex items-center justify-center gap-2.5"
          >
            <Camera size={18} />
            <span>{t('hero.contactMe')}</span>
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 w-full max-w-5xl mt-4">
          <StatCard value="10+" label={t('hero.stats.yearsExperience')} />
          <StatCard value="50+" label={t('hero.stats.musicVideos')} />
          <StatCard value="15+" label={t('hero.stats.filmFestivals')} />
          <StatCard value="100%" label={t('hero.stats.cinematicDelivery')} />
        </div>

        {/* Scroll prompt */}
        <div
          className="mt-12 flex flex-col items-center gap-2 text-[#A0A0A0]/60 hover:text-[#00FF66] transition-colors cursor-pointer"
          onClick={onExploreProjects}
        >
          <span className="text-[10px] uppercase font-mono tracking-[0.3em]">{t('hero.explore')}</span>
          <div className="w-5 h-8 rounded-full border border-white/20 flex items-start justify-center p-1">
            <div className="w-1.5 h-1.5 rounded-full bg-[#00FF66] animate-bounce shadow-[0_0_8px_#00FF66]" />
          </div>
        </div>
      </div>
    </section>
  );
};
