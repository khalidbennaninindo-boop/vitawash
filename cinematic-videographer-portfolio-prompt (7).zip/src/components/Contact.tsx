import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CONTACT_DATA } from '../data/portfolioData';
import { Mail, Phone, MapPin, Send, MessageCircle, ExternalLink, CheckCircle2, Copy, Check } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundFx } from '../utils/audioFx';
import { SectionHeading } from './SectionHeading';

export const Contact: React.FC = () => {
  const { t } = useTranslation();
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    subject: 'Music Video / Shoot Inquiry',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const handleCopy = (text: string, type: 'phone' | 'email') => {
    soundFx.playClick();
    navigator.clipboard.writeText(text);
    if (type === 'phone') {
      setCopiedPhone(true);
      setTimeout(() => setCopiedPhone(false), 2500);
    } else {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2500);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundFx.playClick();
    if (!formState.name || !formState.email || !formState.message) return;

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      soundFx.playSuccess();
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 }, colors: ['#00FF66', '#0D5C2A', '#FFFFFF'] });
    }, 1000);
  };

  return (
    <section id="contact" className="relative py-28 bg-black border-t border-white/5 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#00FF66]/5 rounded-full blur-[250px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionHeading
          badge={t('contact.badge')}
          title={t('contact.title')}
          accent={t('contact.titleAccent')}
          description={t('contact.description')}
          align="center"
        />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Info card */}
          <div className="lg:col-span-5 space-y-8">
            <div className="p-8 rounded-3xl glass-card border border-[#00FF66]/40 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 bg-[#0D5C2A]/30 rounded-bl-2xl border-l border-b border-[#00FF66]/30 text-[10px] font-mono text-[#00FF66] font-bold">
                {t('contact.productionsVault')}
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-heading font-extrabold text-white uppercase">{CONTACT_DATA.name}</h3>
                  <p className="text-xs font-mono text-[#00FF66] tracking-widest mt-1 uppercase">{CONTACT_DATA.title}</p>
                </div>

                <div className="space-y-4 pt-4 border-t border-white/10 text-sm">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-xl bg-black border border-white/10 text-[#00FF66] flex-shrink-0">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <span className="text-xs font-mono text-[#A0A0A0] uppercase block">{t('contact.locationAddress')}</span>
                      <strong className="text-white block font-semibold">{CONTACT_DATA.location}</strong>
                      <span className="text-xs text-[#A0A0A0] mt-0.5 block">{CONTACT_DATA.address}</span>
                    </div>
                  </div>

                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-xl bg-black border border-white/10 text-[#00FF66] flex-shrink-0">
                        <Phone size={20} />
                      </div>
                      <div>
                        <span className="text-xs font-mono text-[#A0A0A0] uppercase block">{t('contact.directCall')}</span>
                        <a href={`tel:${CONTACT_DATA.phoneClean}`} className="text-white font-mono text-base font-bold hover:text-[#00FF66] transition-colors">
                          {CONTACT_DATA.phone}
                        </a>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCopy(CONTACT_DATA.phone, 'phone')}
                      className="p-2 rounded-lg bg-white/5 hover:bg-[#00FF66]/20 text-white hover:text-[#00FF66] transition-colors mt-2"
                    >
                      {copiedPhone ? <Check size={16} className="text-[#00FF66]" /> : <Copy size={16} />}
                    </button>
                  </div>

                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-xl bg-black border border-white/10 text-[#00FF66] flex-shrink-0">
                        <Mail size={20} />
                      </div>
                      <div>
                        <span className="text-xs font-mono text-[#A0A0A0] uppercase block">{t('contact.officialEmail')}</span>
                        <a href={`mailto:${CONTACT_DATA.email}`} className="text-white font-mono text-sm sm:text-base font-bold hover:text-[#00FF66] transition-colors break-all">
                          {CONTACT_DATA.email}
                        </a>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCopy(CONTACT_DATA.email, 'email')}
                      className="p-2 rounded-lg bg-white/5 hover:bg-[#00FF66]/20 text-white hover:text-[#00FF66] transition-colors mt-2"
                    >
                      {copiedEmail ? <Check size={16} className="text-[#00FF66]" /> : <Copy size={16} />}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/10">
                  <a href="https://wa.me/212643625293" target="_blank" rel="noopener noreferrer" onClick={() => soundFx.playClick()} className="py-3 rounded-xl btn-neon text-xs font-bold uppercase flex items-center justify-center gap-2 tracking-wide text-center">
                    <MessageCircle size={16} className="fill-black" />
                    <span>{t('contact.whatsapp')}</span>
                  </a>
                  <a href={`mailto:${CONTACT_DATA.email}?subject=Production%20Inquiry`} onClick={() => soundFx.playClick()} className="py-3 rounded-xl btn-outline-neon text-xs font-bold uppercase flex items-center justify-center gap-2 tracking-wide text-center">
                    <Mail size={16} />
                    <span>{t('contact.emailMe')}</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Socials */}
            <div className="p-6 rounded-2xl glass-panel border border-white/10 space-y-4">
              <h4 className="text-xs font-mono uppercase text-[#00FF66] tracking-[0.2em] mb-3 flex items-center justify-between">
                <span>{t('contact.officialChannels')}</span>
                <span className="text-white/40">{CONTACT_DATA.socials.length} {t('contact.links')}</span>
              </h4>
              <div className="grid grid-cols-2 gap-2.5">
                {CONTACT_DATA.socials.map((soc, idx) => (
                  <a
                    key={idx}
                    href={soc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => soundFx.playClick()}
                    className="p-3 rounded-xl bg-black border border-white/10 hover:border-[#00FF66] hover:bg-[#00FF66]/10 text-center transition-all duration-300 flex flex-col items-center justify-center group"
                  >
                    <span className="text-xs font-bold text-white group-hover:text-[#00FF66] uppercase transition-colors flex items-center gap-1">
                      {soc.name}
                      <ExternalLink size={11} className="opacity-60 group-hover:opacity-100" />
                    </span>
                    <span className="text-[9px] font-mono text-[#A0A0A0]/60 mt-1 truncate max-w-full">{soc.handle}</span>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-3xl glass-panel border border-white/10 shadow-2xl relative">
              <div className="mb-8">
                <h3 className="text-2xl font-heading font-extrabold text-white uppercase flex items-center justify-between">
                  <span>{t('contact.sendMessage')}</span>
                  <span className="text-xs font-mono text-[#00FF66] font-normal">{t('contact.responseTime')}</span>
                </h3>
                <p className="text-xs text-[#A0A0A0] mt-1">{t('contact.fillOut')}</p>
              </div>

              {submitted ? (
                <div className="py-16 text-center space-y-6 bg-black/60 rounded-2xl border border-[#00FF66]/40 p-6 animate-in zoom-in-95 duration-500">
                  <div className="w-20 h-20 rounded-full bg-[#00FF66]/20 border-2 border-[#00FF66] text-[#00FF66] mx-auto flex items-center justify-center shadow-[0_0_30px_#00FF66]">
                    <CheckCircle2 size={42} />
                  </div>
                  <h4 className="text-3xl font-heading font-extrabold text-white uppercase text-glow">{t('contact.success')}</h4>
                  <p
                    className="text-base text-[#A0A0A0] max-w-md mx-auto leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: t('contact.successMessage', { name: formState.name }) }}
                  />
                  <button
                    onClick={() => {
                      soundFx.playClick();
                      setSubmitted(false);
                      setFormState({ name: '', email: '', subject: 'Music Video / Shoot Inquiry', message: '' });
                    }}
                    className="px-6 py-2.5 rounded-xl btn-outline-neon text-xs uppercase tracking-wider"
                  >
                    {t('contact.sendAnother')}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2">{t('contact.form.fullName')}</label>
                      <input
                        type="text"
                        required
                        placeholder={t('contact.form.placeholders.name')}
                        value={formState.name}
                        onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-black border border-white/15 focus:border-[#00FF66] text-white text-sm focus:outline-none transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2">{t('contact.form.email')}</label>
                      <input
                        type="email"
                        required
                        placeholder={t('contact.form.placeholders.email')}
                        value={formState.email}
                        onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-black border border-white/15 focus:border-[#00FF66] text-white text-sm focus:outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2">{t('contact.form.projectType')}</label>
                    <select
                      value={formState.subject}
                      onChange={(e) => setFormState({ ...formState, subject: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-black border border-white/15 focus:border-[#00FF66] text-white text-sm focus:outline-none transition-colors"
                    >
                      {Object.keys(t('contact.form.projectTypes', { returnObjects: true }) as object).map((key) => (
                        <option key={key} value={key}>
                          {t(`contact.form.projectTypes.${key}`)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-[#00FF66] uppercase mb-2">{t('contact.form.overview')}</label>
                    <textarea
                      required
                      rows={5}
                      placeholder={t('contact.form.placeholders.overview')}
                      value={formState.message}
                      onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-black border border-white/15 focus:border-[#00FF66] text-white text-sm focus:outline-none transition-colors resize-y"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="text-[11px] font-mono text-[#A0A0A0]/60">{t('contact.form.confidential')}</span>
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-8 py-4 rounded-xl btn-neon font-extrabold uppercase text-sm tracking-widest flex items-center gap-2 shadow-xl disabled:opacity-50 transition-all duration-300"
                    >
                      {loading ? (
                        <span className="animate-pulse flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-black animate-ping" />
                          {t('contact.form.sending')}
                        </span>
                      ) : (
                        <>
                          <Send size={18} />
                          <span>{t('contact.form.sendInquiry')}</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
