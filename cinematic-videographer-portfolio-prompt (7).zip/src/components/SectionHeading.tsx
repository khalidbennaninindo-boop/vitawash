import React from 'react';
import { useScrollReveal } from '../hooks/useScrollReveal';

interface Props {
  badge: string;
  title: string;
  accent?: string;
  description?: string;
  align?: 'left' | 'center';
}

export const SectionHeading: React.FC<Props> = ({
  badge,
  title,
  accent,
  description,
  align = 'left',
}) => {
  const { ref, visible } = useScrollReveal<HTMLDivElement>();

  const alignment = align === 'center' ? 'text-center items-center' : 'text-left items-start';

  return (
    <div
      ref={ref}
      className={`flex flex-col ${alignment} mb-14 transition-all duration-1000 ease-out ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
    >
      <div className="flex items-center gap-2 text-xs font-mono uppercase text-[#00FF66] tracking-[0.3em] mb-3">
        {align === 'center' && <span className="w-8 h-[1px] bg-[#00FF66]" />}
        <span>{badge}</span>
        <span className="w-8 h-[1px] bg-[#00FF66]" />
      </div>
      <h2 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold uppercase tracking-tight text-white font-heading">
        {title}{' '}
        {accent && <span className="text-[#00FF66]">{accent}</span>}
      </h2>
      {description && (
        <p className={`text-base text-[#A0A0A0] mt-4 max-w-2xl leading-relaxed ${align === 'center' ? 'mx-auto' : ''}`}>
          {description}
        </p>
      )}
    </div>
  );
};
