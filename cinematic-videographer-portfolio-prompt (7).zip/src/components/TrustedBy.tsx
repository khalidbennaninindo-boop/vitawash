import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Award } from 'lucide-react';

type Brand = { name: string };

const BRANDS: Brand[] = [
  { name: 'Haier' },
  { name: 'CMR' },
  { name: 'Mawazine Festival' },
  { name: 'Alien Prod' },
  { name: 'The Voice' },
  { name: 'AliExpress' },
  { name: 'Ministère de la Culture' },
  { name: 'Warner Music' },
  { name: 'Techspace' },
  { name: 'Qanawate' },
  { name: 'DONE' },
  { name: 'La Varenne' },
  { name: 'Tobigo' },
  { name: 'Al Itkane' },
];

function BrandTile({ brand }: { brand: Brand }) {
  const initials = useMemo(() => {
    const parts = brand.name
      .replace(/[^A-Za-z0-9 ]/g, ' ')
      .split(' ')
      .filter(Boolean);
    if (parts.length === 0) return 'B';
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }, [brand.name]);

  return (
    <div className="group relative flex h-24 sm:h-28 min-w-[180px] sm:min-w-[220px] items-center justify-center rounded-2xl border border-white/10 bg-white/[0.02] px-5 transition-all duration-300 hover:-translate-y-1 hover:border-[#00FF66]/50 hover:shadow-[0_0_25px_rgba(0,255,102,0.2)]">
      <div className="flex items-center gap-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-black text-xs font-extrabold tracking-[0.2em] text-white transition-all duration-300 group-hover:border-[#00FF66] group-hover:text-[#00FF66] group-hover:shadow-[0_0_18px_rgba(0,255,102,0.35)]">
          {initials}
        </div>
        <div className="text-left">
          <div className="text-sm sm:text-base font-semibold uppercase tracking-wide text-white transition-colors duration-300 group-hover:text-[#00FF66]">
            {brand.name}
          </div>
          <div className="mt-1 text-[10px] font-mono uppercase tracking-[0.3em] text-[#A0A0A0] transition-colors duration-300 group-hover:text-white/70">
            ★ PARTNER
          </div>
        </div>
      </div>
    </div>
  );
}

function MarqueeRow({ direction = 'left' }: { direction?: 'left' | 'right' }) {
  const rowBrands = useMemo(() => [...BRANDS, ...BRANDS], []);
  return (
    <div className={`trusted-marquee trusted-marquee--${direction}`}>
      <div className="trusted-marquee__track">
        {rowBrands.map((brand, index) => (
          <BrandTile key={`${direction}-${brand.name}-${index}`} brand={brand} />
        ))}
      </div>
    </div>
  );
}

export const TrustedBy: React.FC = () => {
  const { t } = useTranslation();
  const sectionRef = useRef<HTMLElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = sectionRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true);
      },
      { threshold: 0.15 }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`relative w-full border-y border-white/5 bg-black py-24 sm:py-28 transition-all duration-1000 ${
        visible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
      }`}
    >
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_top,rgba(0,255,102,0.08),transparent_42%)]" />

      <div className="mx-auto flex w-full max-w-none flex-col gap-8 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto w-full max-w-7xl">
          <div className="flex items-end justify-between gap-6 border-b border-white/10 pb-6">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-[0.3em] text-[#00FF66]">
                <Award size={16} />
                <span className="h-px w-10 bg-[#00FF66]" />
                <span>{t('trustedBy.badge')}</span>
              </div>
              <h2 className="mt-3 text-3xl sm:text-5xl font-heading font-extrabold uppercase tracking-tight text-white">
                {t('trustedBy.title')} <span className="text-[#00FF66]">{t('trustedBy.titleAccent')}</span>
              </h2>
            </div>
            <p className="hidden max-w-xl text-sm text-[#A0A0A0] md:block">{t('trustedBy.description')}</p>
          </div>
          <p className="mt-4 max-w-2xl text-sm text-[#A0A0A0] md:hidden">{t('trustedBy.description')}</p>
        </div>

        <div className="space-y-5">
          <MarqueeRow direction="left" />
          <MarqueeRow direction="right" />
        </div>
      </div>
    </section>
  );
};
