import React, { useEffect, useState } from 'react';
import { soundFx } from '../utils/audioFx';

interface Props {
  grainEnabled: boolean;
  onLoaded?: () => void;
}

export const CinematicOverlay: React.FC<Props> = ({ grainEnabled, onLoaded }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [mousePos, setMousePos] = useState({ x: -100, y: -100 });
  const [hovered, setHovered] = useState(false);
  const [shutterOpen, setShutterOpen] = useState(false);

  // Progress
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setShutterOpen(true);
            soundFx.playShutter();
            setTimeout(() => {
              setLoading(false);
              onLoaded?.();
            }, 800);
          }, 400);
          return 100;
        }
        const next = prev + Math.floor(Math.random() * 25) + 5;
        return next > 100 ? 100 : next;
      });
    }, 70);
    return () => clearInterval(interval);
  }, [onLoaded]);

  // Custom cursor
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => setMousePos({ x: e.clientX, y: e.clientY });
    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      setHovered(
        !!(
          target &&
          (target.tagName === 'BUTTON' ||
            target.tagName === 'A' ||
            target.closest('button') ||
            target.closest('a') ||
            target.getAttribute('role') === 'button')
        )
      );
    };
    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseover', handleMouseOver);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseover', handleMouseOver);
    };
  }, []);

  return (
    <>
      {grainEnabled && <div className="film-grain-overlay" />}

      {/* Custom cursor */}
      <div
        className="fixed top-0 left-0 pointer-events-none z-[1000] hidden md:block"
        style={{ left: `${mousePos.x}px`, top: `${mousePos.y}px`, transform: 'translate(-50%, -50%)' }}
      >
        <div
          className={`rounded-full transition-all duration-300 ${
            hovered
              ? 'w-14 h-14 bg-[#00FF66]/20 border border-[#00FF66] box-glow'
              : 'w-3 h-3 bg-[#00FF66] shadow-[0_0_12px_#00FF66]'
          }`}
        />
        {hovered && (
          <div className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-[#00FF66] uppercase tracking-tighter opacity-80">
            VIEW
          </div>
        )}
      </div>

      {/* Loading screen */}
      {loading && (
        <div className="fixed inset-0 z-[2000] pointer-events-auto overflow-hidden flex flex-col justify-between">
          <div className={`w-full bg-black flex items-end justify-center pb-8 border-b border-[#00FF66]/20 shutter-top ${shutterOpen ? 'h-0 opacity-0' : 'h-1/2 opacity-100'}`}>
            <div className="text-center transition-opacity duration-300">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0D5C2A]/40 border border-[#00FF66]/30 mb-3 text-xs text-[#00FF66] tracking-widest font-mono uppercase animate-pulse">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping mr-1" />
                REC [4K CINEMATIC SYSTEM]
              </div>
              <h1 className="text-3xl md:text-5xl font-heading font-extrabold tracking-widest text-white uppercase text-glow">
                MOHAMMED <span className="text-[#00FF66]">BELHOUARI</span>
              </h1>
              <p className="text-xs md:text-sm text-[#A0A0A0] tracking-[0.3em] uppercase mt-2">
                Senior Videographer • Photographer • Creative Director
              </p>
            </div>
          </div>

          <div className={`w-full bg-black flex items-start justify-center pt-8 border-t border-[#00FF66]/20 shutter-bottom ${shutterOpen ? 'h-0 opacity-0' : 'h-1/2 opacity-100'}`}>
            <div className="w-64 max-w-[80vw] text-center">
              <div className="flex justify-between items-center text-xs font-mono text-[#A0A0A0] mb-2">
                <span>INITIALIZING LENS...</span>
                <span className="text-[#00FF66] font-bold">{progress}%</span>
              </div>
              <div className="w-full h-1 bg-[#0D5C2A]/30 rounded-full overflow-hidden">
                <div className="h-full bg-[#00FF66] shadow-[0_0_15px_#00FF66] transition-all duration-150" style={{ width: `${progress}%` }} />
              </div>
              <div className="mt-4 text-[10px] text-[#A0A0A0]/60 font-mono">RABAT, MOROCCO • HIGH-END PRODUCTION</div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
