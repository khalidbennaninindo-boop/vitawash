import React from 'react';
import { useTranslation } from 'react-i18next';
import { SKILL_CATEGORIES } from '../data/portfolioData';
import { Video, Layers, Camera, Palette, Headphones, Sparkles, Check, Cpu } from 'lucide-react';
import { soundFx } from '../utils/audioFx';
import { SectionHeading } from './SectionHeading';

const CATEGORY_KEYS = ['videoEditing', 'motionDesign', 'photography', 'graphicDesign', 'audio'];

const getCategoryIcon = (iconName: string) => {
  switch (iconName) {
    case 'Video': return <Video size={22} className="text-[#00FF66]" />;
    case 'Layers': return <Layers size={22} className="text-[#00FF66]" />;
    case 'Camera': return <Camera size={22} className="text-[#00FF66]" />;
    case 'Palette': return <Palette size={22} className="text-[#00FF66]" />;
    case 'Headphones': return <Headphones size={22} className="text-[#00FF66]" />;
    default: return <Sparkles size={22} className="text-[#00FF66]" />;
  }
};

// Map tool names to translation keys
const TOOL_KEYS: Record<string, string> = {
  'Adobe Premiere Pro': 'premiere',
  'Final Cut Pro': 'finalCut',
  'Adobe After Effects': 'afterEffects',
  'Cinema 4D': 'cinema4d',
  'Adobe Photoshop': 'photoshop',
  'Adobe Illustrator': 'illustrator',
  'Logic Pro X': 'logicPro',
};

const CREATIVE_KEYS = [
  'creativeDirection', 'storytelling', 'cinematography', 'photographySkill', 'videography',
  'motionGraphics', 'colorGrading', 'soundDesign', 'visualBranding', 'projectManagement'
];

export const Skills: React.FC = () => {
  const { t } = useTranslation();

  const softwareCategories = SKILL_CATEGORIES.slice(0, 5);
  const creativeCategory = SKILL_CATEGORIES[5];

  return (
    <section id="skills" className="relative py-28 bg-black border-t border-white/5 overflow-hidden">
      <div className="absolute bottom-0 left-1/3 w-[600px] h-[600px] bg-[#00FF66]/5 rounded-full blur-[200px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-6">
          <SectionHeading
            badge={t('skills.badge')}
            title={t('skills.title')}
            accent={t('skills.titleAccent')}
          />
          <div className="flex items-center gap-2 font-mono text-xs text-[#A0A0A0]/80 bg-[#0D5C2A]/20 border border-[#00FF66]/30 px-4 py-2 rounded-xl backdrop-blur-md">
            <Cpu size={14} className="text-[#00FF66] animate-pulse" />
            <span>{t('skills.workflow')}</span>
          </div>
        </div>

        {/* Software cards */}
        <div className="mb-14">
          <h3 className="text-sm font-mono uppercase tracking-widest text-white/80 mb-6 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00FF66]" />
            {t('skills.softwareMastery')}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {softwareCategories.map((cat, idx) => (
              <div
                key={idx}
                onMouseEnter={() => soundFx.playHover()}
                className="p-7 rounded-2xl glass-panel border border-white/10 hover:border-[#00FF66] flex flex-col justify-between group relative overflow-hidden transition-all duration-500 hover:-translate-y-1"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#0D5C2A]/20 rounded-bl-full group-hover:bg-[#00FF66]/10 transition-colors duration-500 pointer-events-none" />

                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="p-3.5 rounded-xl bg-black/80 border border-[#00FF66]/40 group-hover:shadow-[0_0_15px_rgba(0,255,102,0.3)] transition-all">
                      {getCategoryIcon(cat.iconName)}
                    </div>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-white/5 text-[#A0A0A0]">
                      {t('skills.advancedSuite')}
                    </span>
                  </div>

                  <h4 className="text-xl font-heading font-extrabold text-white uppercase tracking-wider mb-4 group-hover:text-[#00FF66] transition-colors">
                    {t(`skills.categories.${CATEGORY_KEYS[idx]}`)}
                  </h4>

                  <div className="space-y-4">
                    {cat.items.map((item, itemIdx) => {
                      const toolKey = TOOL_KEYS[item.name] || item.name.toLowerCase().replace(/\s+/g, '');
                      return (
                        <div key={itemIdx} className="space-y-1.5">
                          <div className="flex justify-between items-center text-sm font-semibold">
                            <span className="text-white flex items-center gap-2">
                              <Check size={14} className="text-[#00FF66]" />
                              {t(`skills.tools.${toolKey}`, item.name)}
                            </span>
                            <span className="font-mono text-xs text-[#00FF66]">{item.level || 95}%</span>
                          </div>
                          <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden border border-white/10">
                            <div
                              className="h-full bg-gradient-to-r from-[#0D5C2A] to-[#00FF66] rounded-full shadow-[0_0_8px_rgba(0,255,102,0.6)] transition-all duration-1000"
                              style={{ width: `${item.level || 95}%` }}
                            />
                          </div>
                          {item.description && (
                            <p className="text-[11px] text-[#A0A0A0]/70 leading-relaxed pt-1">
                              {t(`skills.tools.${toolKey}Desc`, item.description)}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Creative mastery */}
        <div className="mt-16 p-8 md:p-10 rounded-3xl glass-card border border-[#00FF66]/40 shadow-2xl relative overflow-hidden">
          <div className="absolute -top-24 -right-24 w-80 h-80 bg-[#00FF66]/10 rounded-full blur-[100px] pointer-events-none" />

          <div className="max-w-3xl mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0D5C2A] text-[#00FF66] text-xs font-mono mb-3">
              <Sparkles size={14} />
              <span>{t('skills.directorProfiles')}</span>
            </div>
            <h3 className="text-2xl sm:text-4xl font-heading font-extrabold uppercase text-white">
              {t(`skills.categories.creative`)}
            </h3>
            <p className="text-[#A0A0A0] text-sm md:text-base mt-2">{t('skills.creativeDescription')}</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
            {creativeCategory.items.map((skill, idx) => (
              <div
                key={idx}
                onMouseEnter={() => soundFx.playHover()}
                className="p-4 rounded-xl bg-black/80 border border-white/10 hover:border-[#00FF66] text-center flex flex-col items-center justify-center group transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,255,102,0.2)] hover:-translate-y-1"
              >
                <div className="w-2.5 h-2.5 rounded-full bg-[#00FF66]/40 group-hover:bg-[#00FF66] group-hover:shadow-[0_0_8px_#00FF66] mb-2.5 transition-all" />
                <span className="text-xs sm:text-sm font-bold text-white group-hover:text-[#00FF66] transition-colors uppercase tracking-wide">
                  {t(`skills.tools.${CREATIVE_KEYS[idx]}`, skill.name)}
                </span>
                <span className="text-[10px] font-mono text-[#A0A0A0]/60 mt-1">{t('skills.expertYears')}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
