import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from './locales/en.json';
import fr from './locales/fr.json';
import ar from './locales/ar.json';

const resources = {
  en: { translation: en },
  fr: { translation: fr },
  ar: { translation: ar },
};

// Detect saved preference or fall back to browser language (en default)
let initialLang = 'en';
if (typeof window !== 'undefined') {
  const saved = window.localStorage.getItem('mb_lang');
  if (saved && ['en', 'fr', 'ar'].includes(saved)) {
    initialLang = saved;
  } else {
    const nav = (navigator.language || 'en').toLowerCase();
    if (nav.startsWith('fr')) initialLang = 'fr';
    else if (nav.startsWith('ar')) initialLang = 'ar';
  }
}

// Apply document direction right away to avoid flash
if (typeof document !== 'undefined') {
  document.documentElement.setAttribute('dir', initialLang === 'ar' ? 'rtl' : 'ltr');
  document.documentElement.setAttribute('lang', initialLang);
}

i18n.use(initReactI18next).init({
  resources,
  lng: initialLang,
  fallbackLng: 'en',
  supportedLngs: ['en', 'fr', 'ar'],
  interpolation: {
    escapeValue: false,
  },
  returnObjects: true,
  returnEmptyString: false,
});

export default i18n;
