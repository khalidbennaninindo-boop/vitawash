export type ProjectCategory = 
  | 'Music Videos'
  | 'Commercials'
  | 'Photography'
  | 'Festivals'
  | 'Fashion'
  | 'Behind The Scenes'
  | 'Motion Graphics';

export interface Project {
  id: string;
  title: string;
  clientOrArtist: string;
  category: ProjectCategory;
  year: string;
  description: string;
  imageUrl: string;
  videoUrl?: string;
  youtubeId?: string;
  youtubePlaylistUrl?: string;
  tags: string[];
  featured?: boolean;
}

export interface ExperienceItem {
  id: string;
  company: string;
  subTitle?: string;
  role: string;
  period: string;
  responsibilities?: string[];
  description?: string;
  highlights?: string[];
  location?: string;
  featuredWork?: string[];
  youtubeId?: string;
  youtubePlaylistUrl?: string;
  mediaTitle?: string;
  imageUrl?: string;
}

export interface SkillCategory {
  title: string;
  iconName: string;
  items: {
    name: string;
    level?: number; 
    description?: string;
  }[];
}

export interface EducationItem {
  degree: string;
  institution: string;
  year?: string;
  badge: string;
}

export interface LanguageItem {
  name: string;
  level: string;
  percentage: number;
}

export interface SocialLink {
  name: string;
  url: string;
  icon: string;
  handle: string;
}
