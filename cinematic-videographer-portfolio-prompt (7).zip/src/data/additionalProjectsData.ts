export interface AdditionalProject {
  id: string;
  title: string;
  clientOrArtist: string;
  category: string;
  year: string;
  description: string;
  fileId: string;
  previewUrl: string;
  downloadUrl: string;
  thumbnailUrl: string;
  tags: string[];
}

// Google Drive helpers
// The /preview URL works reliably in iframes for video playback
const drivePreview = (fileId: string) => `https://drive.google.com/file/d/${fileId}/preview`;
const driveDownload = (fileId: string) => `https://drive.google.com/uc?export=download&id=${fileId}`;
const driveThumb = (fileId: string) => `https://drive.google.com/thumbnail?id=${fileId}&sz=w1200`;

export const ADDITIONAL_PROJECTS: AdditionalProject[] = [
  {
    id: "add-1",
    title: "15ᵗʰ Done Ambassadors Day",
    clientOrArtist: "DONE Agency",
    category: "Events",
    year: "2025",
    description: "Official coverage of the 15th anniversary Ambassador Day celebration, capturing premium event moments, guest interactions, and the brand's milestone achievement.",
    fileId: "14OE24Ai8kmZfWZLezV7aTzNwPdxKHnA8",
    previewUrl: drivePreview("14OE24Ai8kmZfWZLezV7aTzNwPdxKHnA8"),
    downloadUrl: driveDownload("14OE24Ai8kmZfWZLezV7aTzNwPdxKHnA8"),
    thumbnailUrl: driveThumb("14OE24Ai8kmZfWZLezV7aTzNwPdxKHnA8"),
    tags: ["Event Coverage", "Ambassador Day", "Brand Milestone", "4K"]
  },
  {
    id: "add-2",
    title: "Bunzy — Music Video",
    clientOrArtist: "Bunzy",
    category: "Music Videos",
    year: "2025",
    description: "Music video production featuring dynamic visual storytelling, cinematic lighting, and seamless performance capture for the artist's latest release.",
    fileId: "1SfSK084DX9Mo46lWVhu2cii-y52q990N",
    previewUrl: drivePreview("1SfSK084DX9Mo46lWVhu2cii-y52q990N"),
    downloadUrl: driveDownload("1SfSK084DX9Mo46lWVhu2cii-y52q990N"),
    thumbnailUrl: driveThumb("1SfSK084DX9Mo46lWVhu2cii-y52q990N"),
    tags: ["Music Video", "Artist", "Cinematic", "Performance"]
  },
  {
    id: "add-3",
    title: "Chic EVENTS — Production",
    clientOrArtist: "Chic Events",
    category: "Commercials",
    year: "2025",
    description: "Premium event production showcase highlighting sophisticated venue coverage, luxury ambiance, and high-end event cinematography.",
    fileId: "1vTynxtvNKZ1N3FdGbegWFKdOybOZyIXg",
    previewUrl: drivePreview("1vTynxtvNKZ1N3FdGbegWFKdOybOZyIXg"),
    downloadUrl: driveDownload("1vTynxtvNKZ1N3FdGbegWFKdOybOZyIXg"),
    thumbnailUrl: driveThumb("1vTynxtvNKZ1N3FdGbegWFKdOybOZyIXg"),
    tags: ["Events", "Luxury", "Venue", "Cinematography"]
  },
  {
    id: "add-4",
    title: "CREEP END LAST",
    clientOrArtist: "DONE Agency",
    category: "Motion Graphics",
    year: "2025",
    description: "Creepy cinematic short with atmospheric tension, moody color grading, and intense visual effects editing.",
    fileId: "1iS4VDCwWlozjhDa1Cs5QtvmMDZQHoQEN",
    previewUrl: drivePreview("1iS4VDCwWlozjhDa1Cs5QtvmMDZQHoQEN"),
    downloadUrl: driveDownload("1iS4VDCwWlozjhDa1Cs5QtvmMDZQHoQEN"),
    thumbnailUrl: driveThumb("1iS4VDCwWlozjhDa1Cs5QtvmMDZQHoQEN"),
    tags: ["Short Film", "Moody", "VFX", "Cinematic"]
  },
  {
    id: "add-5",
    title: "CTA Episode 2 — Abdeljabbar",
    clientOrArtist: "DONE Agency",
    category: "Content Series",
    year: "2025",
    description: "Second episode of the popular CTA content series featuring Abdeljabbar, with engaging storytelling and dynamic production quality.",
    fileId: "1tTkzAa3x8PvaxoNkgeRsfHbRFmEOCWAT",
    previewUrl: drivePreview("1tTkzAa3x8PvaxoNkgeRsfHbRFmEOCWAT"),
    downloadUrl: driveDownload("1tTkzAa3x8PvaxoNkgeRsfHbRFmEOCWAT"),
    thumbnailUrl: driveThumb("1tTkzAa3x8PvaxoNkgeRsfHbRFmEOCWAT"),
    tags: ["Content Series", "Episode", "Storytelling", "YouTube"]
  },
  {
    id: "add-6",
    title: "DONE X CRUSTY — Collab",
    clientOrArtist: "DONE × Crusty",
    category: "Commercials",
    year: "2025",
    description: "Creative brand collaboration video showcasing product integration, energetic visuals, and punchy commercial editing.",
    fileId: "1BRZ6Uzk7lXcjyNEATVBkzpqBGBBks2om",
    previewUrl: drivePreview("1BRZ6Uzk7lXcjyNEATVBkzpqBGBBks2om"),
    downloadUrl: driveDownload("1BRZ6Uzk7lXcjyNEATVBkzpqBGBBks2om"),
    thumbnailUrl: driveThumb("1BRZ6Uzk7lXcjyNEATVBkzpqBGBBks2om"),
    tags: ["Brand Collab", "Commercial", "Product", "Creative"]
  },
  {
    id: "add-7",
    title: "Food Challenge",
    clientOrArtist: "DONE Agency",
    category: "Social Media",
    year: "2025",
    description: "Viral food challenge video with fast-paced editing, engaging personalities, and high-energy social media content style.",
    fileId: "1ACwEJiauMxwAtsHowxYDTheQK90Cae1n",
    previewUrl: drivePreview("1ACwEJiauMxwAtsHowxYDTheQK90Cae1n"),
    downloadUrl: driveDownload("1ACwEJiauMxwAtsHowxYDTheQK90Cae1n"),
    thumbnailUrl: driveThumb("1ACwEJiauMxwAtsHowxYDTheQK90Cae1n"),
    tags: ["Food", "Challenge", "Social Media", "Viral"]
  },
  {
    id: "add-8",
    title: "Questions about DONE",
    clientOrArtist: "DONE Agency",
    category: "Behind The Scenes",
    year: "2025",
    description: "Behind-the-scenes interview style video answering questions about the DONE agency, its culture, and creative process.",
    fileId: "1YwUcAeW7GXic0pGgzZLU00HZe9ZmnZQt",
    previewUrl: drivePreview("1YwUcAeW7GXic0pGgzZLU00HZe9ZmnZQt"),
    downloadUrl: driveDownload("1YwUcAeW7GXic0pGgzZLU00HZe9ZmnZQt"),
    thumbnailUrl: driveThumb("1YwUcAeW7GXic0pGgzZLU00HZe9ZmnZQt"),
    tags: ["Interview", "BTS", "Agency", "Documentary"]
  }
];
