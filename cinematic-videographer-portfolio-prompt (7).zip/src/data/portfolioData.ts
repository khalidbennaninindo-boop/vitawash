import { Project, ExperienceItem, SkillCategory, EducationItem, LanguageItem, SocialLink } from '../types/portfolio';

export const HERO_DATA = {
  name: "MOHAMMED BELHOUARI",
  title: "Senior Videographer • Photographer • Creative Director",
  shortIntro: "Passionate videographer and photographer with over 10 years of experience creating cinematic visual content. Specialized in music videos, festivals, commercial campaigns, photography, motion graphics and digital storytelling for internationally recognized artists and brands.",
  location: "Rabat, Morocco",
  heroVideoUrl: "https://videos.pexels.com/video-files/12171745/12171745-uhd_3840_2160_25fps.mp4",
  heroBgImage: "https://i.postimg.cc/j2Gv3TwZ/Take-the-clap-Shot-by-souhailfilalii-Edit-by-thereal-ferdy-photography-photooftheday-(1).jpg",
  stats: [
    { value: "10+", label: "Years Experience" },
    { value: "50+", label: "Music Videos Directed" },
    { value: "15+", label: "Film Festivals & Events" },
    { value: "100%", label: "Cinematic Delivery" }
  ]
};

export const ABOUT_DATA = {
  bioParagraphs: [
    "I am Mohammed Belhouari, a Senior Videographer and Photographer based in Rabat, Morocco.",
    "I manage complete audiovisual production from concept to final delivery including directing, filming, editing, color grading, sound design and motion graphics."
  ],
  domains: [
    { title: "International Film Festivals", desc: "Marrakech International Film Festival, Saudi Film Festival, Mawazine" },
    { title: "Music Videos", desc: "Official visual identities & directed narratives for chart-topping artists" },
    { title: "Commercial Campaigns", desc: "High-impact visual advertisements & promotional content" },
    { title: "Luxury Brands", desc: "Elegant aesthetics, refined product cinematography and storytelling" },
    { title: "Social Media Content", desc: "Optimized vertical cinematic formats & best-of highlights" },
    { title: "Photography", desc: "Editorial, portraiture, concert, product and behind-the-scenes mastery" },
    { title: "Motion Graphics", desc: "Dynamic Title design, visual VFX accents and brand animation" },
    { title: "Post Production", desc: "Advanced editing, specialized color grading (DaVinci/Premiere) and audio design" }
  ],
  profileImage: "https://images.pexels.com/photos/23384400/pexels-photo-23384400.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900"
};

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: "Video Editing",
    iconName: "Video",
    items: [
      { name: "Adobe Premiere Pro", level: 98, description: "Advanced timelines, multi-cam workflows, speed editing" },
      { name: "Final Cut Pro", level: 92, description: "Apple-optimized cinematic cutting & color staging" }
    ]
  },
  {
    title: "Motion Design",
    iconName: "Layers",
    items: [
      { name: "Adobe After Effects", level: 95, description: "VFX tracking, dynamic kinetic typography, compositing" },
      { name: "Cinema 4D", level: 85, description: "3D animation setups, stage product lighting, motion elements" }
    ]
  },
  {
    title: "Photography",
    iconName: "Camera",
    items: [
      { name: "Adobe Photoshop", level: 98, description: "High-end portrait retouching, color grading & manipulation" }
    ]
  },
  {
    title: "Graphic Design",
    iconName: "Palette",
    items: [
      { name: "Adobe Illustrator", level: 90, description: "Vector identity, production branding & storyboard elements" }
    ]
  },
  {
    title: "Audio & Sound Design",
    iconName: "Headphones",
    items: [
      { name: "Logic Pro X", level: 88, description: "Sound design engineering, audio mixing, atmosphere layers" }
    ]
  },
  {
    title: "Creative Mastery",
    iconName: "Sparkles",
    items: [
      { name: "Creative Direction", level: 98 },
      { name: "Storytelling", level: 96 },
      { name: "Cinematography", level: 99 },
      { name: "Photography", level: 98 },
      { name: "Videography", level: 98 },
      { name: "Motion Graphics", level: 92 },
      { name: "Color Grading", level: 97 },
      { name: "Sound Design", level: 88 },
      { name: "Visual Branding", level: 94 },
      { name: "Project Management", level: 95 }
    ]
  }
];

export const EXPERIENCE_ITEMS: ExperienceItem[] = [
  {
    id: "exp-1",
    company: "DONE",
    role: "Senior Videographer & Photographer",
    period: "May 2025 – Present",
    location: "Rabat / Hybrid",
    responsibilities: [
      "Video Production & High-End Photography",
      "Brand Campaigns & Strategic Digital Storytelling",
      "Motion Graphics & Dynamic Title Design",
      "Product Photography & Luxury Aesthetic Showpieces",
      "Social Media Content & Viral Vertical Reels",
      "Team Leadership & Production Guidance",
      "End-to-end Post Production & Cinema Color Grading"
    ],
    highlights: ["Leading multi-channel luxury production timelines", "Standardizing high-end 4K/6K camera workflows"],
    youtubeId: "oJMRoq1AD2k",
    youtubePlaylistUrl: "https://www.youtube.com/watch?v=oJMRoq1AD2k",
    mediaTitle: "DONE — Official Production Showreel"
  },
  {
    id: "exp-2",
    company: "Everybody Loves Touda",
    subTitle: "Nabil Ayouch Film",
    role: "Freelance Production Partner",
    period: "Aug 2024 – Oct 2024",
    location: "Morocco",
    imageUrl: "https://i.postimg.cc/cgmLpp5G/120x160-EVERYBODY-LOVES-TOUDA-29-08-HD-526x712.jpg",
    responsibilities: [
      "Visual Design & Cinema Quality Videography",
      "Motion Graphics & Promotional Title sequences",
      "Creative Concepts & Digital Assets",
      "Best Of Production & Behind The Scenes Coverage",
      "Promotional Content creation for international film releases"
    ],
    highlights: ["Contributed to one of Morocco's most internationally anticipated cinema productions"]
  },
  {
    id: "exp-3",
    company: "Warner Music",
    role: "Music Video Director",
    period: "Aug 2024 – Sep 2024",
    location: "Morocco / MENA",
    description: "Directed two official high-profile music videos for renowned artist Khalil Guennich. Handled complete production from creative concept to post-production and grading.",
    responsibilities: [
      "Directed two official music videos for Khalil Guennich",
      "Complete visual narrative treatment & art direction",
      "Lighting design, crew supervision & camera choreography",
      "Final editorial cut and color grade for Warner Music specifications"
    ],
    featuredWork: ["Khalil Guennich Official Singles (x2)"],
    youtubeId: "drz0zKw2Rko",
    youtubePlaylistUrl: "https://www.youtube.com/watch?v=drz0zKw2Rko&list=OLAK5uy_mzP9ZKD1ud8qg6ndEp_uswqWyZphxi2wA",
    mediaTitle: "Warner Music: Khalil Guennich Official MV"
  },
  {
    id: "exp-4",
    company: "FJConcept MENA",
    role: "Senior Photographer • Videographer • Designer",
    period: "Sep 2023 – Mar 2024",
    location: "MENA Region",
    responsibilities: [
      "Official Coverage: Marrakech International Film Festival",
      "Official Coverage: Saudi Film Festival",
      "High-profile Red Carpet Videography & Editorial Photography",
      "Festival Branding & Visual Theme Development",
      "High-engagement Real-time Social Media Campaigns"
    ],
    highlights: ["Captured global cinema legends on world stages in Marrakech and Saudi Arabia"]
  },
  {
    id: "exp-5",
    company: "MMP Studio",
    role: "Creative Director",
    period: "Jan 2015 – May 2022",
    location: "Rabat, Morocco",
    imageUrl: "https://i.postimg.cc/qhjpb8z3/120x160-MMP-STUDIO-29-08-HD-526x712.jpg",
    responsibilities: [
      "Directed Commercials for top-tier Moroccan & regional brands",
      "Directed & produced dozens of Music Videos",
      "Studio & Outdoor Commercial Photography",
      "Motion Graphics & Brand Graphic Design",
      "Complete Art Direction & Talent Styling",
      "Mastering Post Production Pipelines"
    ],
    highlights: ["7+ years guiding creative vision and mentoring production teams"]
  },
  {
    id: "exp-6",
    company: "The Voice",
    role: "Freelance Photographer & Videographer",
    period: "April 2020",
    location: "Morocco",
    imageUrl: "https://i.postimg.cc/vgqdLbNV/the-voice-official-poster.jpg",
    description: "Worked directly with star vocalists Hamza Labyad and Redwan Asmar to create cinematic promotional video releases and striking editorial photography.",
    responsibilities: [
      "Collaboration with Hamza Labyad & Redwan Asmar",
      "Promotional artist showreel & teaser production",
      "Editorial artist photography & artwork imagery"
    ],
    featuredWork: ["Hamza Labyad Promo", "Redwan Asmar Promo"]
  },
  {
    id: "exp-7",
    company: "Mawazine Festival",
    role: "Freelance Photographer & Videographer",
    period: "July 2019",
    location: "Rabat, Morocco",
    imageUrl: "https://i.postimg.cc/rDcYm7fY/mawazine-official-poster.jpg",
    description: "Produced exhilarating stage and behind-the-scenes media coverage for one of the world's biggest music festivals, covering headline performances of top stars.",
    responsibilities: [
      "Covered headline performances of Myriam Fares, Manal, Lbenj, and Youssra Saouf",
      "Live multi-angle dynamic stage videography",
      "High-energy concert crowd photography & artist portraits",
      "Rapid turnaround social media clips & highlights"
    ],
    featuredWork: ["Myriam Fares Live", "Manal Stage Shoot", "Lbenj Concert Highlights", "Youssra Saouf Coverage"]
  },
  {
    id: "exp-8",
    company: "RT Studio",
    role: "Photographer • Videographer • Motion Graphic Designer",
    period: "June 2013 – October 2015",
    location: "Morocco",
    responsibilities: [
      "Created dynamic broadcast & web Commercials",
      "Developed custom animated Motion Graphics & show title decks",
      "Professional studio photography & editorial assignments",
      "End-to-end video production & audio synchronization"
    ]
  }
];

export const FEATURED_ARTISTS = [
  "Saad Lamjarred",
  "Hatim Ammor",
  "L7or",
  "Stormy",
  "Meryem Fares",
  "Khalil Guennich",
  "Kawtar Berrani",
  "Zakaria Lghafouli",
  "Dounia Batma",
  "Meryem Zaïmi",
  "Draganov",
  "Adil Charfi",
  "Leil",
  "Nabil Elhouri"
];

export const PROJECTS_DATA: Project[] = [
  {
    id: "proj-1",
    title: "Warner Music: Khalil Guennich Official MV",
    clientOrArtist: "Khalil Guennich / Warner Music",
    category: "Music Videos",
    year: "2024",
    description: "Official visual directed for Warner Music release. Featuring cinematic lighting in deep amber and emerald shadows, high-frame-rate emotional portraits, and intricate motion tracking.",
    imageUrl: "https://images.pexels.com/photos/12083806/pexels-photo-12083806.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    videoUrl: "https://videos.pexels.com/video-files/6274273/6274273-uhd_3840_2160_30fps.mp4",
    youtubeId: "drz0zKw2Rko",
    youtubePlaylistUrl: "https://www.youtube.com/watch?v=drz0zKw2Rko&list=OLAK5uy_mzP9ZKD1ud8qg6ndEp_uswqWyZphxi2wA",
    tags: ["Director", "Warner Music", "4K Cinema", "Color Grading"],
    featured: true
  },
  {
    id: "proj-2",
    title: "Mawazine Festival: Headline Stages",
    clientOrArtist: "Myriam Fares • Manal • Lbenj",
    category: "Festivals",
    year: "2019",
    description: "High-energy festival videography & iconic editorial stage photography captured during Rabat's world-renowned Mawazine Festival before crowds of over 100,000 spectators.",
    imageUrl: "https://i.postimg.cc/rDcYm7fY/mawazine-official-poster.jpg",
    tags: ["Concert Coverage", "Live Stage", "Festival Branding", "Rapid Edit"],
    featured: true
  },
  {
    id: "proj-3",
    title: "Everybody Loves Touda — Behind The Scenes",
    clientOrArtist: "Nabil Ayouch Film",
    category: "Behind The Scenes",
    year: "2024",
    description: "Exclusive production diary, promotional motion packages, and actor candid coverage on set of Nabil Ayouch's internationally celebrated Moroccan film.",
    imageUrl: "https://images.pexels.com/photos/23384400/pexels-photo-23384400.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    tags: ["Feature Film", "BTS", "Cinema Set", "Promotional Package"],
    featured: true
  },
  {
    id: "proj-4",
    title: "Marrakech & Saudi Film Festivals Red Carpet",
    clientOrArtist: "FJConcept MENA",
    category: "Festivals",
    year: "2023-2024",
    description: "Stunning cinematic red carpet teasers, VIP editorial studio portraits, and animated title decks celebrating world cinema legends in Morocco and Saudi Arabia.",
    imageUrl: "https://images.pexels.com/photos/30247038/pexels-photo-30247038.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    tags: ["Red Carpet", "Film Festival", "Luxury Styling", "MENA"],
    featured: true
  },
  {
    id: "proj-5",
    title: "Saad Lamjarred & Hatim Ammor Creative Series",
    clientOrArtist: "Saad Lamjarred • Hatim Ammor",
    category: "Music Videos",
    year: "2021-2022",
    description: "Conceptual lighting setups, artistic styling, and cinematic visual branding designed for prominent Moroccan Pop & Urban recording stars.",
    imageUrl: "https://i.postimg.cc/gXrpqs1Y/saad-lamjarred-hatim-ammor.jpg",
    tags: ["Music Video", "Artist Branding", "Creative Direction", "Lighting"],
    featured: true
  },
  {
    id: "proj-6",
    title: "Luxury Brand Cinematic Commercials",
    clientOrArtist: "DONE & MMP Studio Clients",
    category: "Commercials",
    year: "2024-2025",
    description: "High-end product films featuring robotic camera motion, deep macro cinematography, dynamic color science, and sophisticated soundscapes.",
    imageUrl: "https://images.pexels.com/photos/7292783/pexels-photo-7292783.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    tags: ["Commercial", "Luxury Brand", "Product Cinematography", "Motion Design"],
    featured: false
  },
  {
    id: "proj-7",
    title: "Editorial Fashion & Portraiture Studio",
    clientOrArtist: "Various Celebrities & Fashion Houses",
    category: "Fashion",
    year: "2024",
    description: "Dark luxury fashion editorials highlighting dramatic shadowplay, neon green accents, bespoke wardrobe silhouettes, and immaculate Photoshop retouching.",
    imageUrl: "https://images.pexels.com/photos/12083806/pexels-photo-12083806.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    tags: ["Fashion Photography", "Editorial Retouch", "Studio", "Vogue Aesthetic"],
    featured: false
  },
  {
    id: "proj-8",
    title: "Urban Nights: L7or, Stormy & Draganov",
    clientOrArtist: "L7or • Stormy • Draganov",
    category: "Photography",
    year: "2023",
    description: "Gritty, moody urban street photography and promotional video teasers designed to mirror the authentic lyrical energy of contemporary North African hip-hop icons.",
    imageUrl: "https://i.postimg.cc/4YmwmZzw/urban-nights-l7or-stormy-draganov.jpg",
    tags: ["Urban Photography", "Hip Hop", "Night Shoots", "Cinematic Stills"],
    featured: false
  },
  {
    id: "proj-9",
    title: "Kinetic Motion Graphics & Broadcast VFX",
    clientOrArtist: "RT Studio • MMP Studio",
    category: "Motion Graphics",
    year: "2022-2025",
    description: "Broadcast title design, 3D product animations in Cinema 4D, glowing HUD interface elements, and custom transitions engineered for commercials and music videos.",
    imageUrl: "https://images.pexels.com/photos/7292783/pexels-photo-7292783.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    tags: ["Motion Graphics", "Cinema 4D", "After Effects", "VFX"],
    featured: false
  }
];

export const EDUCATION_ITEMS: EducationItem[] = [
  {
    degree: "Audiovisual License",
    institution: "BIGSOFT Rabat",
    badge: "Degree",
    year: "Rabat, Morocco"
  },
  {
    degree: "Photoshop Essentials Certification",
    institution: "Alison",
    badge: "Certified Specialist",
    year: "Professional Mastery"
  },
  {
    degree: "After Effects Motion Graphics Certification",
    institution: "Alison",
    badge: "Certified Specialist",
    year: "VFX & Animation"
  }
];

export const LANGUAGES_DATA: LanguageItem[] = [
  { name: "Arabic", level: "Native", percentage: 100 },
  { name: "French", level: "Professional", percentage: 95 },
  { name: "English", level: "Professional", percentage: 90 }
];

export const CONTACT_DATA: {
  name: string;
  title: string;
  location: string;
  address: string;
  phone: string;
  phoneClean: string;
  email: string;
  socials: SocialLink[];
} = {
  name: "Mohammed Belhouari",
  title: "Senior Videographer & Photographer",
  location: "Rabat, Morocco",
  address: "23 Gr Chourouk Hay Nahda 3, 10210 Rabat",
  phone: "+212 6 43 62 52 93",
  phoneClean: "212643625293",
  email: "Me.belhouari@gmail.com",
  socials: [
    { name: "LinkedIn", url: "https://www.linkedin.com/in/mohammedbelhouari/", icon: "Linkedin", handle: "Mohammed Belhouari" },
    { name: "YouTube", url: "https://youtube.com", icon: "Youtube", handle: "Mohammed Belhouari" },
    { name: "Instagram", url: "https://instagram.com", icon: "Instagram", handle: "@mohammedbelhouari" },
    { name: "WhatsApp", url: "https://wa.me/212643625293", icon: "MessageCircle", handle: "+212 6 43 62 52 93" }
  ]
};
