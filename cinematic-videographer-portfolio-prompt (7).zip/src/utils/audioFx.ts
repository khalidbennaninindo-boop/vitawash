// Web Audio API sound generator for luxury cinematic feedback

class CinematicAudio {
  private ctx: AudioContext | null = null;
  private enabled: boolean = false;

  constructor() {
    // Lazy initialize AudioContext on user interaction
  }

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
  }

  public setEnabled(val: boolean) {
    this.enabled = val;
    if (val) {
      this.init();
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      this.playTone(180, 0.1, 'sine', 0.15);
    }
  }

  public getEnabled(): boolean {
    return this.enabled;
  }

  public playClick() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    this.playTone(800, 0.03, 'triangle', 0.08);
  }

  public playHover() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    this.playTone(440, 0.05, 'sine', 0.02);
  }

  public playShutter() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    this.playTone(120, 0.15, 'sawtooth', 0.12);
    setTimeout(() => this.playTone(90, 0.2, 'sawtooth', 0.08), 80);
  }

  public playSuccess() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    this.playTone(523.25, 0.15, 'sine', 0.1); // C5
    setTimeout(() => this.playTone(659.25, 0.15, 'sine', 0.1), 100); // E5
    setTimeout(() => this.playTone(783.99, 0.25, 'sine', 0.12), 200); // G5
  }

  private playTone(freq: number, duration: number, type: OscillatorType, gainVal: number) {
    try {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
      
      gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch {
      // Ignore audio errors if blocked by browser autoplay policy
    }
  }
}

export const soundFx = new CinematicAudio();
