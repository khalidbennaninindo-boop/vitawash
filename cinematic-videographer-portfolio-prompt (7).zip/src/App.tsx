import { useState, useEffect } from 'react';
import { CinematicOverlay } from './components/CinematicOverlay';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Experience } from './components/Experience';
import { FeaturedProjects } from './components/FeaturedProjects';
import { AdditionalProjects } from './components/AdditionalProjects';
import { TrustedBy } from './components/TrustedBy';
import { EducationLanguages } from './components/EducationLanguages';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { CVModal } from './components/CVModal';
import { BookingModal } from './components/BookingModal';

export function App() {
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [grainEnabled, setGrainEnabled] = useState(true);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isCVOpen, setIsCVOpen] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  const handleScrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    console.log(
      '%c🎬 MOHAMMED BELHOUARI — SENIOR VIDEOGRAPHER & PHOTOGRAPHER \n%c⚡ Rabat, Morocco • 10+ Years Cinematic Excellence',
      'color: #00FF66; font-size: 16px; font-weight: bold; background: #000; padding: 6px;',
      'color: #A0A0A0; font-size: 12px; background: #000; padding: 4px;'
    );
  }, []);

  return (
    <div className="min-h-screen bg-black text-white relative">
      <CinematicOverlay grainEnabled={grainEnabled} onLoaded={() => setIsLoaded(true)} />

      <Navbar
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        grainEnabled={grainEnabled}
        setGrainEnabled={setGrainEnabled}
        onOpenBooking={() => setIsBookingOpen(true)}
        onOpenCV={() => setIsCVOpen(true)}
      />

      <main className={`transition-opacity duration-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
        <Hero
          onExploreProjects={() => handleScrollToSection('projects')}
          onContact={() => handleScrollToSection('contact')}
          onOpenBooking={() => setIsBookingOpen(true)}
        />
        <About onOpenCV={() => setIsCVOpen(true)} onOpenBooking={() => setIsBookingOpen(true)} />
        <Skills />
        <Experience />
        <FeaturedProjects onOpenBooking={() => setIsBookingOpen(true)} />
        <AdditionalProjects />
        <TrustedBy />
        <EducationLanguages />
        <Contact />
      </main>

      <Footer />

      <CVModal isOpen={isCVOpen} onClose={() => setIsCVOpen(false)} />
      <BookingModal isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} />
    </div>
  );
}

export default App;
